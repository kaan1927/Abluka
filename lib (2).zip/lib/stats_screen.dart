// lib/stats_screen.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class StatsScreen extends StatefulWidget {
  const StatsScreen({super.key});

  @override
  State<StatsScreen> createState() => _StatsScreenState();
}

class _StatsScreenState extends State<StatsScreen> {
  int _totalGames = 0;
  int _player1Wins = 0;
  int _player2Wins = 0;
  List<dynamic> _matches = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    setState(() {
      _isLoading = true;
    });

    final prefs = await SharedPreferences.getInstance();
    
    // Load basic stats
    final totalGames = prefs.getInt('totalGames') ?? 0;
    final player1Wins = prefs.getInt('player1Wins') ?? 0;
    final player2Wins = prefs.getInt('player2Wins') ?? 0;
    
    // Load match history
    final matchesJson = prefs.getString('matches');
    List<dynamic> matches = [];
    if (matchesJson != null) {
      matches = jsonDecode(matchesJson);
    }

    setState(() {
      _totalGames = totalGames;
      _player1Wins = player1Wins;
      _player2Wins = player2Wins;
      _matches = matches;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(
          "İstatistikler",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 24,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF3A1C71),  // Deep purple
              Color(0xFFD76D77),   // Pink
              Color(0xFFFFAF7B),   // Peach
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: _isLoading
              ? const Center(
                  child: CircularProgressIndicator(
                    color: Colors.white,
                  ),
                )
              : _buildStatsContent(),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _loadStats,
        backgroundColor: const Color(0xFFD76D77),
        child: const Icon(Icons.refresh),
      ),
    );
  }

  Widget _buildStatsContent() {
    // Calculate win rates
    double blackWinRate = _totalGames > 0 ? (_player1Wins / _totalGames) * 100 : 0;
    double whiteWinRate = _totalGames > 0 ? (_player2Wins / _totalGames) * 100 : 0;
    
    // Calculate average moves per game
    int totalMoves = 0;
    for (var match in _matches) {
      totalMoves += int.parse(match["moves"] ?? "0");
    }
    double avgMoves = _totalGames > 0 ? totalMoves / _totalGames : 0;
    
    // Count game modes
    int vsAIGames = _matches.where((m) => m["mode"] == "vsAI").length;
    int twoPlayerGames = _matches.where((m) => m["mode"] == "twoPlayer").length;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Overall Stats Card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(30),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Genel İstatistikler",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildStatColumn(
                      icon: Icons.sports_esports,
                      value: "$_totalGames",
                      label: "Toplam Oyun",
                    ),
                    _buildStatColumn(
                      icon: Icons.swap_horiz,
                      value: avgMoves.toStringAsFixed(1),
                      label: "Ort. Hamle",
                    ),
                    _buildStatColumn(
                      icon: Icons.smart_toy,
                      value: "$vsAIGames",
                      label: "AI Oyunu",
                    ),
                    _buildStatColumn(
                      icon: Icons.people,
                      value: "$twoPlayerGames",
                      label: "2 Kişilik",
                    ),
                  ],
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 20),
          
          // Win Rates Card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(30),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Kazanma Oranları",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: _buildWinRateBar(
                        label: "Siyah",
                        wins: _player1Wins,
                        percentage: blackWinRate,
                        color: Colors.black,
                      ),
                    ),
                    const SizedBox(width: 20),
                    Expanded(
                      child: _buildWinRateBar(
                        label: "Beyaz",
                        wins: _player2Wins,
                        percentage: whiteWinRate,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 20),
          
          // Recent Games
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(30),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      "Son Oyunlar",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.pushNamed(context, '/replay');
                      },
                      child: const Text(
                        "Tümünü Gör",
                        style: TextStyle(
                          color: Colors.amber,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                _matches.isEmpty
                    ? Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.white.withAlpha(20),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Center(
                          child: Text(
                            "Henüz oyun geçmişi yok",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      )
                    : Column(
                        children: _matches
                            .take(3) // Show only the last 3 games
                            .map((match) => _buildRecentGameItem(match))
                            .toList(),
                      ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatColumn({
    required IconData icon,
    required String value,
    required String label,
  }) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white.withAlpha(30),
            shape: BoxShape.circle,
          ),
          child: Icon(
            icon,
            color: Colors.white,
            size: 24,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: Colors.white.withAlpha(180),
          ),
        ),
      ],
    );
  }

  Widget _buildWinRateBar({
    required String label,
    required int wins,
    required double percentage,
    required Color color,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  width: 16,
                  height: 16,
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                    border: color == Colors.white
                        ? Border.all(color: Colors.black, width: 1)
                        : null,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            Text(
              "$wins Zafer",
              style: TextStyle(
                color: Colors.white.withAlpha(200),
                fontSize: 14,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Stack(
          children: [
            // Background bar
            Container(
              height: 12,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white.withAlpha(30),
                borderRadius: BorderRadius.circular(6),
              ),
            ),
            // Progress bar
            Container(
              height: 12,
              width: percentage > 0 ? (percentage / 100) * (MediaQuery.of(context).size.width - 112) : 0,
              decoration: BoxDecoration(
                color: color == Colors.white ? Colors.amber : color,
                borderRadius: BorderRadius.circular(6),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          "${percentage.toStringAsFixed(1)}%",
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildRecentGameItem(Map<String, dynamic> match) {
    final winnerText = match['winner'] == 'black' ? 'Siyah' : 'Beyaz';
    final modeText = match['mode'] == 'vsAI' ? 'Yapay Zekaya Karşı' : 'İki Oyunculu';
    
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(20),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () {
            Navigator.pushNamed(
              context,
              '/matchDetail',
              arguments: match,
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white.withAlpha(30),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Icon(
                      match['mode'] == 'vsAI' ? Icons.smart_toy : Icons.people,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        match["matchId"] ?? "Bilinmeyen Maç",
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      Text(
                        "$modeText • ${match["moves"]} Hamle",
                        style: TextStyle(
                          color: Colors.white.withAlpha(180),
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: match['winner'] == 'black' ? Colors.black : Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: match['winner'] == 'white'
                        ? Border.all(color: Colors.black, width: 1)
                        : null,
                  ),
                  child: Text(
                    winnerText,
                    style: TextStyle(
                      color: match['winner'] == 'black' ? Colors.white : Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}