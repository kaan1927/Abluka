/// Abluka oyununda tahta üzerindeki bir konumu temsil eden sınıf.
class BoardPosition {
  /// X koordinatı (satır)
  final int x;
  
  /// Y koordinatı (sütun)
  final int y;
  
  /// Bir konum oluşturur.
  /// 
  /// [x]: X koordinatı (satır)
  /// [y]: Y koordinatı (sütun)
  const BoardPosition(this.x, this.y);
  
  /// Konumun JSON temsilini döndürür.
  Map<String, dynamic> toJson() => {'x': x, 'y': y};
  
  /// JSON'dan bir konum oluşturur.
  factory BoardPosition.fromJson(Map<String, dynamic> json) =>
      BoardPosition(json['x'] as int, json['y'] as int);
  
  /// İki konumun eşit olup olmadığını kontrol eder.
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is BoardPosition && other.x == x && other.y == y;
  
  /// Konumun hash kodunu döndürür.
  @override
  int get hashCode => x.hashCode ^ y.hashCode;
  
  /// Konumun metin temsilini döndürür.
  @override
  String toString() => '($x, $y)';
  
  /// Konumun 7x7 tahta sınırları içinde olup olmadığını kontrol eder.
  bool isValid() => x >= 0 && x < 7 && y >= 0 && y < 7;
  
  /// İki konum arasındaki Manhattan mesafesini hesaplar.
  int distanceTo(BoardPosition other) => (x - other.x).abs() + (y - other.y).abs();
  
  /// Bu konumdan belirtilen yönde bir birim hareket ederek yeni bir konum oluşturur.
  /// 
  /// [dx]: X yönündeki hareket (-1, 0, 1)
  /// [dy]: Y yönündeki hareket (-1, 0, 1)
  BoardPosition move(int dx, int dy) => BoardPosition(x + dx, y + dy);
  
  /// Bu konumun komşu konumlarını döndürür (yatay, dikey ve çapraz).
  List<BoardPosition> getNeighbors() {
    List<BoardPosition> neighbors = [];
    
    for (int dx = -1; dx <= 1; dx++) {
      for (int dy = -1; dy <= 1; dy++) {
        if (dx == 0 && dy == 0) continue; // Kendisi hariç
        
        BoardPosition neighbor = move(dx, dy);
        if (neighbor.isValid()) {
          neighbors.add(neighbor);
        }
      }
    }
    
    return neighbors;
  }
  
  /// Merkez konumu (3, 3) döndürür.
  static BoardPosition get center => const BoardPosition(3, 3);
  
  /// Konumun merkeze olan uzaklığını hesaplar.
  int distanceToCenter() => distanceTo(center);
  
  /// İki konum arasında çapraz hareket olup olmadığını kontrol eder.
  bool isDiagonalTo(BoardPosition other) {
    int dx = (x - other.x).abs();
    int dy = (y - other.y).abs();
    return dx == 1 && dy == 1;
  }
  
  /// İki konum arasında yatay veya dikey hareket olup olmadığını kontrol eder.
  bool isOrthogonalTo(BoardPosition other) {
    int dx = (x - other.x).abs();
    int dy = (y - other.y).abs();
    return (dx == 1 && dy == 0) || (dx == 0 && dy == 1);
  }
  
  /// İki konum arasında bir birim hareket olup olmadığını kontrol eder.
  bool isAdjacentTo(BoardPosition other) {
    int dx = (x - other.x).abs();
    int dy = (y - other.y).abs();
    return (dx <= 1 && dy <= 1) && !(dx == 0 && dy == 0);
  }
  
  /// Konumun köşede olup olmadığını kontrol eder.
  bool isCorner() {
    return (x == 0 || x == 6) && (y == 0 || y == 6);
  }
  
  /// Konumun kenarda olup olmadığını kontrol eder.
  bool isEdge() {
    return x == 0 || x == 6 || y == 0 || y == 6;
  }
}