import 'board_position.dart';

/// Abluka oyununda bir hamleyi temsil eden sınıf.
/// 
/// Her hamle üç bileşenden oluşur:
/// 1. Taşın başlangıç konumu (from)
/// 2. Taşın hedef konumu (to)
/// 3. Engelin yerleştirildiği konum (block)
class GameMove {
  final BoardPosition from;
  final BoardPosition to;
  final BoardPosition block;
  
  /// Bir hamle oluşturur.
  /// 
  /// [from]: Taşın başlangıç konumu
  /// [to]: Taşın hedef konumu
  /// [block]: Engelin yerleştirildiği konum
  GameMove({
    required this.from,
    required this.to,
    required this.block,
  }) {
    // Hamlenin geçerliliğini kontrol et
    _validateMove();
  }
  
  /// Hamlenin geçerliliğini kontrol eder.
  /// 
  /// Geçersiz bir hamle tespit edilirse bir [ArgumentError] fırlatır.
  void _validateMove() {
    // Taş hareketi kontrolü: Taş sadece bir birim hareket edebilir
    int dx = (to.x - from.x).abs();
    int dy = (to.y - from.y).abs();
    
    if (dx > 1 || dy > 1) {
      throw ArgumentError('Geçersiz taş hareketi: Taşlar sadece bir birim hareket edebilir');
    }
    
    // Yerinde durma kontrolü
    if (dx == 0 && dy == 0) {
      throw ArgumentError('Geçersiz taş hareketi: Taş yerinde duramaz');
    }
    
    // Engel yerleştirme kontrolü: Engel, taşın yeni konumuna yerleştirilemez
    if (block.x == to.x && block.y == to.y) {
      throw ArgumentError('Geçersiz engel yerleştirme: Engel, taşın bulunduğu kareye yerleştirilemez');
    }
    
    // Geçici engel kontrolü: Eğer block (-1, -1) ise, bu geçici bir değerdir ve kontrol edilmez
    if (block.x == -1 && block.y == -1) {
      return;
    }
    
    // Tahta sınırları kontrolü
    if (!_isInsideBoard(from) || !_isInsideBoard(to) || !_isInsideBoard(block)) {
      throw ArgumentError('Geçersiz konum: Konumlar tahta sınırları içinde olmalıdır');
    }
  }
  
  /// Bir konumun 7x7 tahta sınırları içinde olup olmadığını kontrol eder.
  /// 
  /// Geçici değerler için (-1, -1) özel bir durum olarak kabul edilir.
  bool _isInsideBoard(BoardPosition pos) {
    // Geçici değer kontrolü
    if (pos.x == -1 && pos.y == -1) {
      return true;
    }
    
    return pos.x >= 0 && pos.x < 7 && pos.y >= 0 && pos.y < 7;
  }
  
  /// Hamlenin JSON temsilini döndürür.
  Map<String, dynamic> toJson() => {
    "from": from.toJson(),
    "to": to.toJson(),
    "block": block.toJson(),
  };
  
  /// JSON'dan bir hamle oluşturur.
  factory GameMove.fromJson(Map<String, dynamic> json) {
    return GameMove(
      from: BoardPosition.fromJson(json["from"]),
      to: BoardPosition.fromJson(json["to"]),
      block: BoardPosition.fromJson(json["block"]),
    );
  }
  
  /// İki hamlenin eşit olup olmadığını kontrol eder.
  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is GameMove &&
           other.from == from &&
           other.to == to &&
           other.block == block;
  }
  
  /// Hamlenin hash kodunu döndürür.
  @override
  int get hashCode => from.hashCode ^ to.hashCode ^ block.hashCode;
  
  /// Hamlenin metin temsilini döndürür.
  @override
  String toString() {
    return 'GameMove(from: $from, to: $to, block: $block)';
  }
  
  /// Geçici bir hamle oluşturur (engel yerleştirme henüz yapılmamış).
  /// 
  /// Bu, iki aşamalı hamle sürecinde ilk aşamayı temsil eder.
  factory GameMove.temporary(BoardPosition from, BoardPosition to) {
    return GameMove(
      from: from,
      to: to,
      block: BoardPosition(-1, -1), // Geçici değer
    );
  }
  
  /// Geçici bir hamleyi tamamlar (engel yerleştirme ekler).
  /// 
  /// Bu, iki aşamalı hamle sürecinde ikinci aşamayı temsil eder.
  GameMove complete(BoardPosition blockPosition) {
    if (block.x != -1 || block.y != -1) {
      throw StateError('Bu hamle zaten tamamlanmış');
    }
    
    return GameMove(
      from: from,
      to: to,
      block: blockPosition,
    );
  }
  
  /// Hamlenin tamamlanıp tamamlanmadığını kontrol eder.
  bool get isComplete => block.x != -1 || block.y != -1;
}