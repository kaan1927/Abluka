import 'board_position.dart';

class GameBoard {
  late List<List<String?>> grid;
  Map<String, int> blocksLeft;
  Map<String, List<BoardPosition>> pieces;
  
  final String player1;
  final String player2;
  final String blockSymbol = 'B'; // Engel sembolü sabit olarak tanımlandı
  
  GameBoard({this.player1 = "black", this.player2 = "white"})
      : blocksLeft = {},
        pieces = {} {
    // Toplam kare sayısı 49, iki oyuncu taşı için 2 kare kullanılır
    // Geriye kalan 47 kare için her oyuncuya eşit sayıda engel verilir (23 veya 24)
    blocksLeft[player1] = 24;
    blocksLeft[player2] = 23; // İkinci oyuncuya 23 engel (toplam 47 engel)
    pieces[player1] = [];
    pieces[player2] = [];
    _initializeBoard();
  }
  
  void _initializeBoard() {
    // 7x7 boş tahta oluştur
    grid = List.generate(7, (_) => List.filled(7, null));
    
    // Oyuncu taşlarını başlangıç pozisyonlarına yerleştir
    // Kurallar: Oyuncular kendi başlangıç sıralarının ortasına yerleştirilir
    _placePiece(player1, 6, 3); // Siyah oyuncu alt sıranın ortasında
    _placePiece(player2, 0, 3); // Beyaz oyuncu üst sıranın ortasında
  }
  
  void _placePiece(String player, int x, int y) {
    if (!isInsideBoard(x, y)) {
      throw ArgumentError('Geçersiz konum: ($x, $y)');
    }
    
    if (grid[x][y] != null) {
      throw ArgumentError('Konum dolu: ($x, $y)');
    }
    
    grid[x][y] = player;
    pieces[player] = [BoardPosition(x, y)];
  }
  
  // Bir konumun tahta içinde olup olmadığını kontrol et
  bool isInsideBoard(int x, int y) => x >= 0 && x < 7 && y >= 0 && y < 7;
  
  // Bir konumun boş olup olmadığını kontrol et
  bool isEmpty(int x, int y) => isInsideBoard(x, y) && grid[x][y] == null;
  
  // Bir konumdan yapılabilecek geçerli hamleleri listele
  List<BoardPosition> getAvailableMoves(BoardPosition from) {
    if (!isInsideBoard(from.x, from.y)) {
      return [];
    }
    
    List<BoardPosition> moves = [];
    
    // Yatay, dikey ve çapraz hareketleri kontrol et (bir birim)
    for (var dx = -1; dx <= 1; dx++) {
      for (var dy = -1; dy <= 1; dy++) {
        if (dx == 0 && dy == 0) continue; // Yerinde durma
        
        int nx = from.x + dx;
        int ny = from.y + dy;
        
        // Hedef konum tahta içinde ve boş olmalı
        if (isEmpty(nx, ny)) {
          moves.add(BoardPosition(nx, ny));
        }
      }
    }
    
    return moves;
  }
  
  // Bir konumdan yapılabilecek hamle sayısını hesapla
  int _countAvailableMoves(BoardPosition from) => getAvailableMoves(from).length;
  
  // Bir oyuncunun taşını hareket ettir
  void movePiece(String player, BoardPosition from, BoardPosition to) {
    // Geçerlilik kontrolleri
    if (!isInsideBoard(from.x, from.y) || !isInsideBoard(to.x, to.y)) {
      throw ArgumentError('Geçersiz konum');
    }
    
    if (grid[from.x][from.y] != player) {
      throw ArgumentError('Başlangıç konumunda oyuncunun taşı yok');
    }
    
    if (grid[to.x][to.y] != null) {
      throw ArgumentError('Hedef konum dolu');
    }
    
    // Hareketin geçerli olup olmadığını kontrol et (bir birim hareket)
    int dx = (to.x - from.x).abs();
    int dy = (to.y - from.y).abs();
    
    if (dx > 1 || dy > 1) {
      throw ArgumentError('Geçersiz hareket: Taşlar sadece bir birim hareket edebilir');
    }
    
    // Taşı hareket ettir
    grid[from.x][from.y] = null;
    grid[to.x][to.y] = player;
    pieces[player] = [to]; // Oyuncunun taş pozisyonunu güncelle
  }
  
  // Bir konuma engel yerleştir
  void placeBlock(int x, int y) {
    // Geçerlilik kontrolleri
    if (!isInsideBoard(x, y)) {
      throw ArgumentError('Geçersiz konum');
    }
    
    if (grid[x][y] != null) {
      throw ArgumentError('Konum dolu');
    }
    
    // Engeli yerleştir
    grid[x][y] = blockSymbol;
  }
  
  // Tahtanın bir kopyasını oluştur
  GameBoard clone() {
    GameBoard newBoard = GameBoard(player1: player1, player2: player2);
    
    // Grid'i kopyala
    newBoard.grid = List.generate(7, (x) => List<String?>.from(grid[x]));
    
    // Kalan engel sayılarını kopyala
    newBoard.blocksLeft = Map.from(blocksLeft);
    
    // Oyuncu taşlarının pozisyonlarını kopyala
    newBoard.pieces = {
      player1: pieces[player1]!.map((bp) => BoardPosition(bp.x, bp.y)).toList(),
      player2: pieces[player2]!.map((bp) => BoardPosition(bp.x, bp.y)).toList(),
    };
    
    return newBoard;
  }
  
  // Tahtayı bir oyuncu perspektifinden değerlendir
  int evaluate(String player) {
    final opponent = player == player1 ? player2 : player1;
    
    // Oyuncu ve rakip taşlarının pozisyonları
    BoardPosition myPos = pieces[player]!.first;
    BoardPosition oppPos = pieces[opponent]!.first;
    
    // Mevcut hamle sayıları
    int myMoves = _countAvailableMoves(myPos);
    int oppMoves = _countAvailableMoves(oppPos);
    
    // Kalan engel sayıları
    int myBlocks = blocksLeft[player]!;
    int oppBlocks = blocksLeft[opponent]!;
    
    // Merkeze olan uzaklıklar
    int myCenterDist = (myPos.x - 3).abs() + (myPos.y - 3).abs();
    int oppCenterDist = (oppPos.x - 3).abs() + (oppPos.y - 3).abs();
    
    // Oyun sonu durumları
    if (myMoves == 0) return -1000; // Oyuncu hareket edemiyorsa, çok kötü
    if (oppMoves == 0) return 1000; // Rakip hareket edemiyorsa, çok iyi
    
    // Genel değerlendirme
    int score = (myMoves - oppMoves) * 10 + // Hareket özgürlüğü farkı
               (myBlocks - oppBlocks) * 2 + // Kalan engel farkı
               (oppMoves <= 2 ? 20 : 0) + // Rakip az hareket edebiliyorsa bonus
               (myMoves <= 1 ? -30 : 0) + // Oyuncu çok az hareket edebiliyorsa ceza
               (oppCenterDist - myCenterDist); // Merkeze yakınlık farkı
    
    return score;
  }
  
  // Oyunun bitip bitmediğini kontrol et
  bool isGameOver() {
    // Oyun, bir oyuncu hareket edemediğinde biter
    final pos1 = pieces[player1]!.first;
    final pos2 = pieces[player2]!.first;
    
    return _countAvailableMoves(pos1) == 0 || _countAvailableMoves(pos2) == 0;
  }
  
  // Kazananı belirle
  String? getWinner() {
    if (!isGameOver()) return null;
    
    final pos1 = pieces[player1]!.first;
    final pos2 = pieces[player2]!.first;
    
    if (_countAvailableMoves(pos1) == 0) return player2;
    if (_countAvailableMoves(pos2) == 0) return player1;
    
    return null; // Beraberlik durumu (teorik olarak mümkün değil)
  }
  
  // Tahtayı JSON formatına dönüştür
  Map<String, dynamic> toJson() {
    return {
      'player1': player1,
      'player2': player2,
      'grid': grid,
      'blocksLeft': blocksLeft,
      'pieces': pieces.map((key, value) =>
          MapEntry(key, value.map((bp) => bp.toJson()).toList())),
    };
  }
  
  // JSON'dan tahta oluştur
  factory GameBoard.fromJson(Map<String, dynamic> json) {
    GameBoard board = GameBoard(
      player1: json['player1'],
      player2: json['player2'],
    );
    
    // Grid'i yükle
    List<dynamic> gridJson = json['grid'];
    board.grid = List.generate(7, (i) => List<String?>.from(gridJson[i]));
    
    // Kalan engel sayılarını yükle
    board.blocksLeft = Map<String, int>.from(json['blocksLeft']);
    
    // Oyuncu taşlarının pozisyonlarını yükle
    Map<String, dynamic> piecesJson = json['pieces'];
    board.pieces = piecesJson.map((key, value) =>
        MapEntry(key, (value as List).map((item) => 
            BoardPosition.fromJson(Map<String, dynamic>.from(item))).toList()));
    
    return board;
  }
  
  // Tahtanın mevcut durumunu metin olarak göster (debug için)
  @override
  String toString() {
    StringBuffer buffer = StringBuffer();
    
    for (int i = 0; i < 7; i++) {
      for (int j = 0; j < 7; j++) {
        String symbol = grid[i][j] ?? '.';
        buffer.write('$symbol ');
      }
      buffer.writeln();
    }
    
    return buffer.toString();
  }
}