// lib/replay_detail_screen.dart
import 'package:flutter/material.dart';
import 'models/game_board.dart';
import 'models/board_position.dart';
import 'widgets/game_board_widget.dart';

class ReplayDetailScreen extends StatefulWidget {
  const ReplayDetailScreen({super.key});

  @override
  State<ReplayDetailScreen> createState() => _ReplayDetailScreenState();
}

class _ReplayDetailScreenState extends State<ReplayDetailScreen> with TickerProviderStateMixin {
  late GameBoard _board;
  late List<Map<String, dynamic>> _moves;
  int _currentMoveIndex = -1;
  bool _isPlaying = false;
  late AnimationController _playbackController;
  double _playbackSpeed = 1.0;

  @override
  void initState() {
    super.initState();
    _playbackController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );
    
    _playbackController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _playNextMove();
      }
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    
    // Get the match data from the route arguments
    final Map<String, dynamic> matchData =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    
    // Initialize the game board
    _board = GameBoard(
      player1: matchData["player1"] ?? "black",
      player2: matchData["player2"] ?? "white",
    );
    
    // Extract the move history
    final List<dynamic> moveHistoryData = matchData["moveHistory"] ?? [];
    _moves = moveHistoryData.map<Map<String, dynamic>>((move) => {
      "from": BoardPosition.fromJson(move["from"]),
      "to": BoardPosition.fromJson(move["to"]),
      "block": BoardPosition.fromJson(move["block"]),
    }).toList();
    
    // Reset to initial state
    _resetReplay();
  }

  @override
  void dispose() {
    _playbackController.dispose();
    super.dispose();
  }

  void _resetReplay() {
    setState(() {
      // Reset the board to initial state
      _board = GameBoard(
        player1: _board.player1,
        player2: _board.player2,
      );
      _currentMoveIndex = -1;
      _isPlaying = false;
      _playbackController.reset();
    });
  }

  void _playNextMove() {
    if (_currentMoveIndex < _moves.length - 1) {
      setState(() {
        _currentMoveIndex++;
        _applyMove(_currentMoveIndex);
      });
      
      if (_isPlaying) {
        _playbackController.forward(from: 0.0);
      }
    } else {
      // End of moves
      setState(() {
        _isPlaying = false;
      });
    }
  }

  void _playPreviousMove() {
    if (_currentMoveIndex >= 0) {
      setState(() {
        _currentMoveIndex--;
        
        // Reset the board and replay all moves up to the current index
        _board = GameBoard(
          player1: _board.player1,
          player2: _board.player2,
        );
        
        for (int i = 0; i <= _currentMoveIndex; i++) {
          _applyMove(i);
        }
      });
    }
  }

  void _applyMove(int moveIndex) {
    if (moveIndex < 0 || moveIndex >= _moves.length) return;
    
    final move = _moves[moveIndex];
    final from = move["from"] as BoardPosition;
    final to = move["to"] as BoardPosition;
    final block = move["block"] as BoardPosition;
    
    // Determine which player made this move (alternating)
    final player = moveIndex % 2 == 0 ? _board.player1 : _board.player2;
    
    // Apply the piece movement
    _board.movePiece(player, from, to);
    
    // Apply the block placement
    if (block.x >= 0 && block.y >= 0) {
      _board.placeBlock(block.x, block.y);
    }
  }

  void _togglePlayback() {
    setState(() {
      _isPlaying = !_isPlaying;
      
      if (_isPlaying) {
        if (_currentMoveIndex >= _moves.length - 1) {
          // If at the end, restart
          _resetReplay();
          _playNextMove();
        } else {
          _playbackController.forward(from: 0.0);
        }
      } else {
        _playbackController.stop();
      }
    });
  }

  void _changePlaybackSpeed() {
    setState(() {
      // Cycle through speeds: 1x -> 2x -> 3x -> 1x
      if (_playbackSpeed == 1.0) {
        _playbackSpeed = 2.0;
      } else if (_playbackSpeed == 2.0) {
        _playbackSpeed = 3.0;
      } else {
        _playbackSpeed = 1.0;
      }
      
      // Update controller duration
      _playbackController.duration = Duration(milliseconds: (1000 / _playbackSpeed).round());
    });
  }

  @override
  Widget build(BuildContext context) {
    final currentMoveNumber = _currentMoveIndex + 1;
    final totalMoves = _moves.length;
    
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(
          "Oyun Tekrarı",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 24,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF3A1C71),  // Deep purple
              Color(0xFFD76D77),   // Pink
              Color(0xFFFFAF7B),   // Peach
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Game info card
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white.withAlpha(30),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white.withAlpha(40),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.replay,
                          color: Colors.white,
                          size: 24,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Hamle İzleme",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Hamle $currentMoveNumber / $totalMoves",
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.white.withAlpha(200),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.amber.withAlpha(200),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          "${_playbackSpeed}x",
                          style: const TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              
              // Game board
              Expanded(
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: AspectRatio(
                      aspectRatio: 1,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white.withAlpha(20),
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withAlpha(50),
                              blurRadius: 10,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        padding: const EdgeInsets.all(8),
                        child: GameBoardWidget(
                          board: _board,
                          onCellTapped: (_, __) {}, // Disable tapping during replay
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              
              // Playback controls
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
                  decoration: BoxDecoration(
                    color: Colors.white.withAlpha(30),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      // Reset button
                      _buildControlButton(
                        icon: Icons.replay,
                        onPressed: _resetReplay,
                        tooltip: "Başa Dön",
                      ),
                      
                      // Previous move button
                      _buildControlButton(
                        icon: Icons.skip_previous,
                        onPressed: _currentMoveIndex >= 0 ? _playPreviousMove : null,
                        tooltip: "Önceki Hamle",
                      ),
                      
                      // Play/Pause button
                      _buildControlButton(
                        icon: _isPlaying ? Icons.pause : Icons.play_arrow,
                        onPressed: _moves.isNotEmpty ? _togglePlayback : null,
                        tooltip: _isPlaying ? "Duraklat" : "Oynat",
                        isLarge: true,
                      ),
                      
                      // Next move button
                      _buildControlButton(
                        icon: Icons.skip_next,
                        onPressed: _currentMoveIndex < _moves.length - 1 ? _playNextMove : null,
                        tooltip: "Sonraki Hamle",
                      ),
                      
                      // Speed button
                      _buildControlButton(
                        icon: Icons.speed,
                        onPressed: _changePlaybackSpeed,
                        tooltip: "Hız: ${_playbackSpeed}x",
                      ),
                    ],
                  ),
                ),
              ),
              
              // Move description
              if (_currentMoveIndex >= 0 && _currentMoveIndex < _moves.length)
                Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white.withAlpha(30),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: _currentMoveIndex % 2 == 0 ? Colors.black : Colors.white,
                            shape: BoxShape.circle,
                            border: _currentMoveIndex % 2 != 0
                                ? Border.all(color: Colors.black, width: 2)
                                : null,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _currentMoveIndex % 2 == 0 ? "Siyah Oyuncu" : "Beyaz Oyuncu",
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                _buildMoveDescription(_moves[_currentMoveIndex]),
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.white.withAlpha(200),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildControlButton({
    required IconData icon,
    required VoidCallback? onPressed,
    required String tooltip,
    bool isLarge = false,
  }) {
    return Tooltip(
      message: tooltip,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(30),
          child: Container(
            width: isLarge ? 60 : 50,
            height: isLarge ? 60 : 50,
            decoration: BoxDecoration(
              color: onPressed != null
                  ? Colors.white.withAlpha(isLarge ? 50 : 30)
                  : Colors.white.withAlpha(10),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: onPressed != null
                  ? Colors.white
                  : Colors.white.withAlpha(100),
              size: isLarge ? 32 : 24,
            ),
          ),
        ),
      ),
    );
  }

  String _buildMoveDescription(Map<String, dynamic> move) {
    final from = move["from"] as BoardPosition;
    final to = move["to"] as BoardPosition;
    final block = move["block"] as BoardPosition;
    
    return "Taş: (${from.x},${from.y}) → (${to.x},${to.y}) | Engel: (${block.x},${block.y})";
  }
}