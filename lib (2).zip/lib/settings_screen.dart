// lib/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'services/vibration_service.dart';
import 'vibration_test_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _difficulty = "Medium";
  bool _soundEnabled = true;
  bool _vibrationEnabled = true;
  bool _showHints = true;
  final VibrationService _vibrationService = VibrationService(); // Titreşim servisi

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _difficulty = prefs.getString('difficulty') ?? "Medium";
      _soundEnabled = prefs.getBool('soundEnabled') ?? true;
      _vibrationEnabled = prefs.getBool('vibrationEnabled') ?? true;
      _showHints = prefs.getBool('showHints') ?? true;
    });
  }

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('difficulty', _difficulty);
    await prefs.setBool('soundEnabled', _soundEnabled);
    await prefs.setBool('vibrationEnabled', _vibrationEnabled);
    await prefs.setBool('showHints', _showHints);

    // Titreşim ayarı kaydedildiğinde ve açıksa test titreşimi ver
    if (_vibrationEnabled) {
      _vibrationService.testVibration();
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Ayarlar kaydedildi!'),
        backgroundColor: Colors.green,
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFD76D77),
        title: const Text(
          '⚙️ Ayarlar',
          style: TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 24,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
        elevation: 4,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF3A1C71),  // Deep purple
              Color(0xFFD76D77),   // Pink
              Color(0xFFFFAF7B),   // Peach
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildSectionTitle('Zorluk Seviyesi'),
                _buildDifficultySelector(),
                
                const SizedBox(height: 24),
                
                _buildSectionTitle('Ses ve Titreşim'),
                _buildToggleSetting(
                  title: 'Ses Efektleri',
                  value: _soundEnabled,
                  onChanged: (value) {
                    setState(() {
                      _soundEnabled = value;
                    });
                  },
                ),
                _buildToggleSetting(
                  title: 'Titreşim',
                  value: _vibrationEnabled,
                  onChanged: (value) {
                    setState(() {
                      _vibrationEnabled = value;
                    });
                    // Titreşim açıldığında test titreşimi ver
                    if (value) {
                      _vibrationService.testVibration();
                    }
                  },
                ),
                
                // Titreşim test butonu
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Center(
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.vibration),
                      label: const Text('Titreşim Testi'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.amber,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const VibrationTestScreen()),
                        );
                      },
                    ),
                  ),
                ),
                
                const SizedBox(height: 24),
                
                _buildSectionTitle('Oyun Ayarları'),
                _buildToggleSetting(
                  title: 'Hamle İpuçlarını Göster',
                  value: _showHints,
                  onChanged: (value) {
                    setState(() {
                      _showHints = value;
                    });
                  },
                ),
                
                const SizedBox(height: 40),
                
                Center(
                  child: SaveButton(
                    onPressed: _saveSettings,
                  ),
                ),
                
                const SizedBox(height: 20),
                
                Center(
                  child: ResetButton(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: const Text('Ayarları Sıfırla'),
                          content: const Text('Tüm ayarlar varsayılan değerlere sıfırlanacak. Emin misiniz?'),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: const Text('İptal'),
                            ),
                            TextButton(
                              onPressed: () {
                                setState(() {
                                  _difficulty = "Medium";
                                  _soundEnabled = true;
                                  _vibrationEnabled = true;
                                  _showHints = true;
                                });
                                _saveSettings();
                                Navigator.pop(context);
                              },
                              child: const Text('Sıfırla'),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
    );
  }

  Widget _buildDifficultySelector() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(40),
        borderRadius: BorderRadius.circular(12),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        children: [
          _buildDifficultyOption('Easy', 'Kolay - AI daha az derinlikte düşünür'),
          const Divider(color: Colors.white24),
          _buildDifficultyOption('Medium', 'Orta - Dengeli zorluk seviyesi'),
          const Divider(color: Colors.white24),
          _buildDifficultyOption('Hard', 'Zor - AI daha derinlemesine düşünür'),
        ],
      ),
    );
  }

  Widget _buildDifficultyOption(String value, String description) {
    return RadioListTile<String>(
      title: Text(
        description.split(' - ')[0],
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
      subtitle: Text(
        description.split(' - ')[1],
        style: TextStyle(
          fontSize: 14,
          color: Colors.white.withAlpha(180),
        ),
      ),
      value: value,
      groupValue: _difficulty,
      activeColor: Colors.amber,
      onChanged: (String? newValue) {
        if (newValue != null) {
          setState(() {
            _difficulty = newValue;
          });
        }
      },
    );
  }

  Widget _buildToggleSetting({
    required String title,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(40),
        borderRadius: BorderRadius.circular(12),
      ),
      child: SwitchListTile(
        title: Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        value: value,
        activeColor: Colors.amber,
        activeTrackColor: Colors.amber.withAlpha(128),
        inactiveThumbColor: Colors.grey.shade300,
        inactiveTrackColor: Colors.grey.shade700,
        onChanged: onChanged,
      ),
    );
  }
}

// Save Button Widget
class SaveButton extends StatelessWidget {
  final VoidCallback onPressed;

  const SaveButton({
    super.key,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 60,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF11998E), Color(0xFF38EF7D)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF38EF7D).withAlpha(100),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(15),
          onTap: onPressed,
          child: const Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.save,
                  color: Colors.white,
                  size: 24,
                ),
                SizedBox(width: 10),
                Text(
                  "Ayarları Kaydet",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Reset Button Widget
class ResetButton extends StatelessWidget {
  final VoidCallback onPressed;

  const ResetButton({
    super.key,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 50,
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(40),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(15),
          onTap: onPressed,
          child: const Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.refresh,
                  color: Colors.white70,
                  size: 20,
                ),
                SizedBox(width: 8),
                Text(
                  "Varsayılan Ayarlara Sıfırla",
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
