import 'package:vibration/vibration.dart';
import 'package:shared_preferences/shared_preferences.dart';

class VibrationService {
  static final VibrationService _instance = VibrationService._internal();
  bool _hasVibrator = false;
  bool _hasAmplitudeControl = false;
  
  factory VibrationService() {
    return _instance;
  }
  
  VibrationService._internal() {
    _init();
  }
  
  Future<void> _init() async {
    try {
      _hasVibrator = await Vibration.hasVibrator() ?? false;
      _hasAmplitudeControl = await Vibration.hasAmplitudeControl() ?? false;
      print("Cihaz titreşim destekliyor mu: $_hasVibrator");
      print("Cihaz titreşim şiddeti kontrolü destekliyor mu: $_hasAmplitudeControl");
    } catch (e) {
      print("Titreşim kontrolü hatası: $e");
      _hasVibrator = false;
      _hasAmplitudeControl = false;
    }
  }
  
  Future<bool> isVibrationEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('vibrationEnabled') ?? true;
  }
  
  Future<void> vibrateOnMove() async {
    if (!_hasVibrator) return;
    
    if (await isVibrationEnabled()) {
      try {
        // Taş hareketi için orta şiddetli titreşim
        if (_hasAmplitudeControl) {
          // Şiddet kontrolü varsa, orta şiddetli titreşim (1-255 arası)
          Vibration.vibrate(duration: 100, amplitude: 128);
        } else {
          // Şiddet kontrolü yoksa, normal titreşim
          Vibration.vibrate(duration: 100);
        }
        print("Taş hareketi titreşimi çalıştırıldı");
      } catch (e) {
        print("Taş hareketi titreşim hatası: $e");
      }
    }
  }
  
  Future<void> vibrateOnGameEnd() async {
    if (!_hasVibrator) return;
    
    if (await isVibrationEnabled()) {
      try {
        // Oyun sonu için özel titreşim deseni
        // [titreşim süresi, bekleme süresi, titreşim süresi, ...]
        if (_hasAmplitudeControl) {
          // Şiddet kontrolü varsa, şiddet değerleriyle titreşim
          Vibration.vibrate(
            pattern: [0, 300, 100, 300, 100],
            intensities: [0, 255, 0, 255, 0],
          );
        } else {
          // Şiddet kontrolü yoksa, sadece desen ile titreşim
          Vibration.vibrate(
            pattern: [0, 300, 100, 300, 100],
          );
        }
        print("Oyun sonu titreşimi çalıştırıldı");
      } catch (e) {
        print("Oyun sonu titreşim hatası: $e");
      }
    }
  }
  
  Future<void> testVibration() async {
    if (!_hasVibrator) {
      print("Bu cihaz titreşimi desteklemiyor");
      return;
    }
    
    try {
      // Test için kısa titreşim
      if (_hasAmplitudeControl) {
        Vibration.vibrate(duration: 200, amplitude: 180);
      } else {
        Vibration.vibrate(duration: 200);
      }
      print("Test titreşimi çalıştırıldı");
    } catch (e) {
      print("Test titreşim hatası: $e");
    }
  }
  
  Future<void> cancelVibration() async {
    if (_hasVibrator) {
      await Vibration.cancel();
    }
  }
}
