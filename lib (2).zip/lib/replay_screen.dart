// lib/replay_screen.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ReplayScreen extends StatefulWidget {
  const ReplayScreen({super.key});
  
  @override
  State<ReplayScreen> createState() => _ReplayScreenState();
}

class _ReplayScreenState extends State<ReplayScreen> {
  List<dynamic> matches = [];
  bool _isLoading = true;
  
  @override
  void initState() {
    super.initState();
    _loadMatches();
  }
  
  Future<void> _loadMatches() async {
    setState(() {
      _isLoading = true;
    });
    
    final prefs = await SharedPreferences.getInstance();
    final matchesJson = prefs.getString('matches');
    
    setState(() {
      if (matchesJson != null) {
        matches = jsonDecode(matchesJson);
      }
      _isLoading = false;
    });
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(
          "Maç Geçmişi",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 24,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF3A1C71),  // Deep purple
              Color(0xFFD76D77),   // Pink
              Color(0xFFFFAF7B),   // Peach
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: _isLoading
              ? const Center(
                  child: CircularProgressIndicator(
                    color: Colors.white,
                  ),
                )
              : matches.isEmpty
                  ? _buildEmptyState()
                  : _buildMatchList(),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _loadMatches,
        backgroundColor: const Color(0xFFD76D77),
        child: const Icon(Icons.refresh),
      ),
    );
  }
  
  Widget _buildEmptyState() {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(30),
        decoration: BoxDecoration(
          color: Colors.white.withAlpha(30),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.history,
              size: 70,
              color: Colors.white.withAlpha(200),
            ),
            const SizedBox(height: 24),
            const Text(
              "Henüz Maç Geçmişi Yok",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Text(
              "Oynadığınız maçlar burada görünecek",
              style: TextStyle(
                fontSize: 16,
                color: Colors.white.withAlpha(200),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildMatchList() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with stats
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(30),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatColumn(
                  icon: Icons.sports_esports,
                  value: "${matches.length}",
                  label: "Toplam Maç",
                ),
                _buildStatColumn(
                  icon: Icons.emoji_events,
                  value: "${_countWins("black")}",
                  label: "Siyah Kazandı",
                ),
                _buildStatColumn(
                  icon: Icons.emoji_events,
                  value: "${_countWins("white")}",
                  label: "Beyaz Kazandı",
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 24),
          
          // Match list title
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white.withAlpha(40),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.history,
                  color: Colors.white,
                  size: 24,
                ),
              ),
              const SizedBox(width: 12),
              const Text(
                "Maç Geçmişi",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          // Match list
          Expanded(
            child: ListView.builder(
              itemCount: matches.length,
              itemBuilder: (context, index) {
                final match = matches[index] as Map<String, dynamic>;
                return ReplayCard(
                  match: match,
                  onTap: () => Navigator.pushNamed(
                    context,
                    '/replayDetail',
                    arguments: match,
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildStatColumn({
    required IconData icon,
    required String value,
    required String label,
  }) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white.withAlpha(30),
            shape: BoxShape.circle,
          ),
          child: Icon(
            icon,
            color: Colors.white,
            size: 24,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: Colors.white.withAlpha(180),
          ),
        ),
      ],
    );
  }
  
  int _countWins(String player) {
    return matches.where((match) => match["winner"] == player).length;
  }
}

class ReplayCard extends StatelessWidget {
  final Map<String, dynamic> match;
  final VoidCallback onTap;

  const ReplayCard({
    super.key,
    required this.match,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final winnerText = match['winner'] == 'black' ? 'Siyah' : 'Beyaz';
    final modeText = match['mode'] == 'vsAI' ? 'Yapay Zekaya Karşı' : 'İki Oyunculu';
    
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(30),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                // Match icon
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.white.withAlpha(40),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Icon(
                      match['mode'] == 'vsAI' ? Icons.smart_toy : Icons.people,
                      color: Colors.white,
                      size: 24,
                    ),
                  ),
                ),
                
                const SizedBox(width: 16),
                
                // Match details
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        match["matchId"] ?? "Bilinmeyen Maç",
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        modeText,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.white.withAlpha(200),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          _buildMatchDetail(
                            icon: Icons.swap_horiz,
                            text: "${match["moves"]} Hamle",
                          ),
                          const SizedBox(width: 16),
                          _buildMatchDetail(
                            icon: Icons.emoji_events,
                            text: "$winnerText Kazandı",
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                
                // Arrow icon
                Icon(
                  Icons.arrow_forward_ios,
                  color: Colors.white.withAlpha(150),
                  size: 16,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
  
  Widget _buildMatchDetail({required IconData icon, required String text}) {
    return Row(
      children: [
        Icon(
          icon,
          color: Colors.white.withAlpha(150),
          size: 14,
        ),
        const SizedBox(width: 4),
        Text(
          text,
          style: TextStyle(
            fontSize: 14,
            color: Colors.white.withAlpha(200),
          ),
        ),
      ],
    );
  }
}