// lib/home_screen.dart
import 'package:flutter/material.dart';
import 'game_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  
  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF3A1C71),  // Deep purple
              Color(0xFFD76D77),   // Pink
              Color(0xFFFFAF7B),   // Peach
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Game Logo/Title Area
                    _buildGameLogo(screenSize),
                    
                    const SizedBox(height: 50),
                    
                    // Game Description
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                      decoration: BoxDecoration(
                        color: Colors.white.withAlpha(40),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: const Text(
                        "Stratejik hamleleri ve zekice engelleri kullanarak rakibini ablukaya al!",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    
                    const SizedBox(height: 40),
                    
                    // Main Menu Buttons
                    MenuButton(
                      icon: Icons.smart_toy,
                      label: "Yapay Zekaya Karşı",
                      gradient: const LinearGradient(
                        colors: [Color(0xFF00B4DB), Color(0xFF0083B0)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const GameScreen(gameMode: GameMode.vsAI),
                          ),
                        );
                      },
                    ),
                    
                    const SizedBox(height: 16),
                    
                    MenuButton(
                      icon: Icons.people,
                      label: "İki Oyunculu",
                      gradient: const LinearGradient(
                        colors: [Color(0xFF11998E), Color(0xFF38EF7D)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const GameScreen(gameMode: GameMode.twoPlayer),
                          ),
                        );
                      },
                    ),
                    
                    const SizedBox(height: 30),
                    
                    // Secondary Menu Buttons in a Row
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        SecondaryMenuButton(
                          icon: Icons.settings,
                          label: "Ayarlar",
                          onPressed: () {
                            Navigator.pushNamed(context, '/settings');
                          },
                        ),
                        
                        SecondaryMenuButton(
                          icon: Icons.bar_chart,
                          label: "İstatistikler",
                          onPressed: () {
                            Navigator.pushNamed(context, '/stats');
                          },
                        ),
                        
                        SecondaryMenuButton(
                          icon: Icons.replay,
                          label: "Tekrar İzle",
                          onPressed: () {
                            Navigator.pushNamed(context, '/replay');
                          },
                        ),
                      ],
                    ),
                    
                    const SizedBox(height: 30),
                    
                    // Game Version
                    Text(
                      "v1.0.0",
                      style: TextStyle(
                        color: Colors.white.withAlpha(150),
                        fontSize: 12,
                      ),
                    ),
                    
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
  
  Widget _buildGameLogo(Size screenSize) {
    return Container(
      margin: const EdgeInsets.only(top: 30),
      child: Column(
        children: [
          // Game Logo
          Container(
            width: screenSize.width * 0.4,
            height: screenSize.width * 0.4,
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withAlpha(50),
                  blurRadius: 15,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Center(
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Black piece
                  Positioned(
                    left: screenSize.width * 0.1,
                    child: Container(
                      width: screenSize.width * 0.12,
                      height: screenSize.width * 0.12,
                      decoration: const BoxDecoration(
                        color: Colors.black,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                  
                  // White piece
                  Positioned(
                    right: screenSize.width * 0.1,
                    child: Container(
                      width: screenSize.width * 0.12,
                      height: screenSize.width * 0.12,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.black, width: 2),
                      ),
                    ),
                  ),
                  
                  // Block
                  Positioned(
                    bottom: screenSize.width * 0.1,
                    child: Container(
                      width: screenSize.width * 0.08,
                      height: screenSize.width * 0.08,
                      decoration: BoxDecoration(
                        color: const Color(0xFFB22222),
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 20),
          
          // Game Title
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              colors: [Color(0xFFFFC837), Color(0xFFFF8008)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ).createShader(bounds),
            child: const Text(
              "ABLUKA",
              style: TextStyle(
                fontSize: 48,
                fontWeight: FontWeight.w900,
                color: Colors.white,
                letterSpacing: 2,
                height: 1,
              ),
            ),
          ),
          
          const SizedBox(height: 5),
          
          // Game Subtitle
          Text(
            "Stratejik Kuşatma Oyunu",
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Colors.white.withAlpha(200),
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}

// Main menu button with gradient background
class MenuButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final LinearGradient gradient;
  final VoidCallback onPressed;

  const MenuButton({
    super.key,
    required this.icon,
    required this.label,
    required this.gradient,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 65,
      decoration: BoxDecoration(
        gradient: gradient,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: gradient.colors.last.withAlpha(100),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(15),
          onTap: onPressed,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Icon(
                  icon,
                  color: Colors.white,
                  size: 28,
                ),
                const SizedBox(width: 15),
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                const Icon(
                  Icons.arrow_forward_ios,
                  color: Colors.white70,
                  size: 18,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Secondary menu button with circular background
class SecondaryMenuButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onPressed;

  const SecondaryMenuButton({
    super.key,
    required this.icon,
    required this.label,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            color: Colors.white.withAlpha(40),
            shape: BoxShape.circle,
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(30),
              onTap: onPressed,
              child: Icon(
                icon,
                color: Colors.white,
                size: 28,
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}