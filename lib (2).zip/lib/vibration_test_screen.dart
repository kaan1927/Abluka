import 'package:flutter/material.dart';
import 'package:vibration/vibration.dart';
import 'services/vibration_service.dart';

class VibrationTestScreen extends StatefulWidget {
  const VibrationTestScreen({super.key});

  @override
  State<VibrationTestScreen> createState() => _VibrationTestScreenState();
}

class _VibrationTestScreenState extends State<VibrationTestScreen> {
  final VibrationService _vibrationService = VibrationService();
  String _testResult = "Henüz test edilmedi";
  bool _vibrationEnabled = true;
  bool _hasVibrator = false;
  bool _hasAmplitudeControl = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
    _checkVibrationCapabilities();
  }

  Future<void> _loadSettings() async {
    _vibrationEnabled = await _vibrationService.isVibrationEnabled();
    setState(() {});
  }

  Future<void> _checkVibrationCapabilities() async {
    try {
      _hasVibrator = await Vibration.hasVibrator() ?? false;
      _hasAmplitudeControl = await Vibration.hasAmplitudeControl() ?? false;
      setState(() {});
    } catch (e) {
      print("Titreşim yetenekleri kontrolü hatası: $e");
    }
  }

  Future<void> _testSimpleVibration() async {
    setState(() {
      _testResult = "Basit titreşim test ediliyor...";
    });
    
    try {
      Vibration.vibrate(duration: 300);
      setState(() {
        _testResult = "Basit titreşim başarılı!";
      });
    } catch (e) {
      setState(() {
        _testResult = "Basit titreşim hatası: $e";
      });
    }
  }

  Future<void> _testPatternVibration() async {
    setState(() {
      _testResult = "Desen titreşimi test ediliyor...";
    });
    
    try {
      // [titreşim süresi, bekleme süresi, titreşim süresi, ...]
      Vibration.vibrate(pattern: [0, 100, 100, 200, 100, 300, 100]);
      setState(() {
        _testResult = "Desen titreşimi başarılı!";
      });
    } catch (e) {
      setState(() {
        _testResult = "Desen titreşimi hatası: $e";
      });
    }
  }

  Future<void> _testAmplitudeVibration() async {
    if (!_hasAmplitudeControl) {
      setState(() {
        _testResult = "Bu cihaz titreşim şiddeti kontrolünü desteklemiyor";
      });
      return;
    }
    
    setState(() {
      _testResult = "Şiddet titreşimi test ediliyor...";
    });
    
    try {
      // Artan şiddetli titreşim
      Vibration.vibrate(
        pattern: [0, 500, 100, 500, 100, 500],
        intensities: [0, 50, 0, 100, 0, 255],
      );
      setState(() {
        _testResult = "Şiddet titreşimi başarılı!";
      });
    } catch (e) {
      setState(() {
        _testResult = "Şiddet titreşimi hatası: $e";
      });
    }
  }

  Future<void> _testGameMoveVibration() async {
    setState(() {
      _testResult = "Taş hareketi titreşimi test ediliyor...";
    });
    
    try {
      await _vibrationService.vibrateOnMove();
      setState(() {
        _testResult = "Taş hareketi titreşimi başarılı!";
      });
    } catch (e) {
      setState(() {
        _testResult = "Taş hareketi titreşimi hatası: $e";
      });
    }
  }

  Future<void> _testGameEndVibration() async {
    setState(() {
      _testResult = "Oyun sonu titreşimi test ediliyor...";
    });
    
    try {
      await _vibrationService.vibrateOnGameEnd();
      setState(() {
        _testResult = "Oyun sonu titreşimi başarılı!";
      });
    } catch (e) {
      setState(() {
        _testResult = "Oyun sonu titreşimi hatası: $e";
      });
    }
  }

  Future<void> _cancelVibration() async {
    try {
      Vibration.cancel();
      setState(() {
        _testResult = "Titreşim iptal edildi";
      });
    } catch (e) {
      setState(() {
        _testResult = "Titreşim iptal hatası: $e";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Titreşim Testi'),
        backgroundColor: const Color(0xFFD76D77),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF6A3093), // Mor
              Color(0xFFA044FF), // Mor-Pembe
              Color(0xFFE73C7E), // Pembe
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        const Text(
                          'Titreşim Durumu',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'Titreşim Ayarı: ${_vibrationEnabled ? "Açık" : "Kapalı"}',
                          style: TextStyle(
                            fontSize: 16,
                            color: _vibrationEnabled ? Colors.green : Colors.red,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          'Titreşim Desteği: ${_hasVibrator ? "Var" : "Yok"}',
                          style: TextStyle(
                            fontSize: 16,
                            color: _hasVibrator ? Colors.green : Colors.red,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          'Şiddet Kontrolü: ${_hasAmplitudeControl ? "Destekleniyor" : "Desteklenmiyor"}',
                          style: TextStyle(
                            fontSize: 16,
                            color: _hasAmplitudeControl ? Colors.green : Colors.orange,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'Son Test Sonucu: $_testResult',
                          style: const TextStyle(
                            fontSize: 16,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                _buildTestButton(
                  title: 'Basit Titreşim',
                  icon: Icons.touch_app,
                  color: Colors.blue,
                  onPressed: _testSimpleVibration,
                ),
                const SizedBox(height: 10),
                _buildTestButton(
                  title: 'Desen Titreşimi',
                  icon: Icons.vibration,
                  color: Colors.green,
                  onPressed: _testPatternVibration,
                ),
                const SizedBox(height: 10),
                _buildTestButton(
                  title: 'Şiddet Titreşimi',
                  icon: Icons.flash_on,
                  color: Colors.orange,
                  onPressed: _testAmplitudeVibration,
                  disabled: !_hasAmplitudeControl,
                ),
                const SizedBox(height: 10),
                _buildTestButton(
                  title: 'Taş Hareketi Titreşimi',
                  icon: Icons.sports_esports,
                  color: Colors.purple,
                  onPressed: _testGameMoveVibration,
                ),
                const SizedBox(height: 10),
                _buildTestButton(
                  title: 'Oyun Sonu Titreşimi',
                  icon: Icons.emoji_events,
                  color: Colors.red,
                  onPressed: _testGameEndVibration,
                ),
                const SizedBox(height: 20),
                _buildTestButton(
                  title: 'Titreşimi İptal Et',
                  icon: Icons.cancel,
                  color: Colors.grey.shade700,
                  onPressed: _cancelVibration,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTestButton({
    required String title,
    required IconData icon,
    required Color color,
    required VoidCallback onPressed,
    bool disabled = false,
  }) {
    return ElevatedButton(
      onPressed: disabled ? null : onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 15),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        disabledBackgroundColor: Colors.grey.shade400,
        disabledForegroundColor: Colors.grey.shade700,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon),
          const SizedBox(width: 10),
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
