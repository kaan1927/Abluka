// lib/widgets/analysis_widget.dart
import 'package:flutter/material.dart';

class AnalysisWidget extends StatelessWidget {
  final String analysis;
  const AnalysisWidget({super.key, required this.analysis});
  
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.amber.shade100,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        analysis,
        style: const TextStyle(fontSize: 18),
      ),
    );
  }
}
