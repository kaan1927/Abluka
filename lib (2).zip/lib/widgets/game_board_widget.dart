// lib/widgets/game_board_widget.dart
import 'package:flutter/material.dart';
import '../models/game_board.dart';
import '../models/board_position.dart';

class GameBoardWidget extends StatelessWidget {
  final GameBoard board;
  final Function(int, int) onCellTapped;

  const GameBoardWidget({super.key, required this.board, required this.onCellTapped});

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1,
      child: Column(
        children: [
          // Top row with number coordinates (0-6)
          Row(
            children: [
              // XY label box in the top-left corner
              _buildXYLabelBox(),
              
              // X-axis coordinates (0-6)
              Expanded(child: _buildTopCoordinates()),
            ],
          ),
          
          // Main board with number coordinates on the left
          Expanded(
            child: Row(
              children: [
                // Left column with number coordinates (0-6)
                _buildLeftCoordinates(),
                
                // The actual game board
                Expanded(
                  child: Container(
                    color: Colors.grey.shade200, // Lighter gray board
                    child: GridView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 7,
                      ),
                      itemCount: 49,
                      itemBuilder: (context, index) {
                        int x = index ~/ 7;
                        int y = index % 7;
                        String? cellValue = board.grid[x][y];
                        Widget child;
                        if (cellValue == null) {
                          child = const SizedBox.shrink();
                        } else if (cellValue == 'B') {
                          child = Container(
                            margin: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: const Color(0xFFB22222), // firebrick
                              borderRadius: BorderRadius.circular(4),
                            ),
                          );
                        } else if (cellValue == "black" || cellValue == "white") {
                          Color pieceColor = cellValue == "black" ? Colors.black : Colors.white;
                          child = Center(
                            child: Container(
                              margin: const EdgeInsets.all(2),
                              child: CircleAvatar(
                                radius: 20,
                                backgroundColor: pieceColor,
                                child: cellValue == "white"
                                    ? Container(
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          border: Border.all(color: Colors.black, width: 2),
                                        ),
                                      )
                                    : null,
                              ),
                            ),
                          );
                        } else {
                          child = const SizedBox.shrink();
                        }
                        
                        return GestureDetector(
                          onTap: () => onCellTapped(x, y),
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey.shade400, width: 0.5),
                            ),
                            child: child,
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Widget to build the XY label box in the top-left corner
  Widget _buildXYLabelBox() {
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: const Color(0xFF52BED4),
        borderRadius: BorderRadius.circular(4),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 2,
            spreadRadius: 0,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Stack(
        children: [
          // X label and arrow
          Positioned(
            top: 2,
            right: 1,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'y',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: Colors.deepOrange.shade700,
                  ),
                ),
                Icon(
                  Icons.arrow_right,
                  size: 10,
                  color: Colors.deepOrange.shade700,
                ),
              ],
            ),
          ),
          // Y label and arrow
          Positioned(
            bottom: 1,
            left: 2,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'x',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: Colors.blue.shade700,
                  ),
                ),
                Icon(
                  Icons.arrow_drop_down,
                  size: 10,
                  color: Colors.blue.shade700,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Widget to build the number coordinates (0-6) at the top (X-axis)
  Widget _buildTopCoordinates() {
    return Container(
      height: 40,
      child: Row(
        children: List.generate(
          7,
          (index) => Expanded(
            child: Container(
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.amber.shade100,
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(4),
                  topRight: Radius.circular(4),
                ),
              ),
              child: Text(
                '$index', // 0-6
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  color: Colors.deepOrange.shade700, // X-axis color
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Widget to build the number coordinates (0-6) on the left (Y-axis)
  Widget _buildLeftCoordinates() {
    return Container(
      width: 40,
      child: Column(
        children: List.generate(
          7,
          (index) => Expanded(
            child: Container(
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.amber.shade100,
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(4),
                  bottomLeft: Radius.circular(4),
                ),
              ),
              child: Text(
                '$index', // 0-6
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  color: Colors.blue.shade700, // Y-axis color
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}