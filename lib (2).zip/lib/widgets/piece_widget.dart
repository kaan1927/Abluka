import 'package:flutter/material.dart';

class PieceWidget extends StatelessWidget {
  final String? cellValue;
  const PieceWidget({super.key, required this.cellValue});

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      transitionBuilder: (Widget child, Animation<double> animation) {
        return ScaleTransition(scale: animation, child: child);
      },
      child: cellValue == null
          ? const SizedBox(key: ValueKey('empty'))
          : Image.asset(
              _selectAsset(cellValue!),
              key: ValueKey(cellValue),
              width: 60,
              height: 60,
            ),
    );
  }

  String _selectAsset(String cellValue) {
    if (cellValue == 'B') {
      return 'assets/images/pieces/block.png';
    }
    if (cellValue == 'Oyuncu 1') {
      return 'assets/images/pieces/player1.png';
    }
    if (cellValue == 'Oyuncu 2') {
      return 'assets/images/pieces/player2.png';
    }
    if (cellValue == 'Yapay Zeka') {
      return 'assets/images/pieces/ai.png';
    }
    return 'assets/images/pieces/player1.png';
  }
}
