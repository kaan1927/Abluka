// lib/widgets/move_history_widget.dart
import 'package:flutter/material.dart';
import '../models/game_move.dart';

class MoveHistoryWidget extends StatelessWidget {
  final List<GameMove> moves;
  const MoveHistoryWidget({super.key, required this.moves});
  
  String _formatMove(GameMove move, int moveNumber) {
    String from = "${String.fromCharCode(97 + move.from.x)}${move.from.y + 1}";
    String to = "${String.fromCharCode(97 + move.to.x)}${move.to.y + 1}";
    String block = "${String.fromCharCode(97 + move.block.x)}${move.block.y + 1}";
    return "$moveNumber. $from -> $to | Block: $block";
  }
  
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: moves.length,
      itemBuilder: (context, index) {
        return ListTile(
          title: Text(_formatMove(moves[index], index + 1)),
        );
      },
    );
  }
}
