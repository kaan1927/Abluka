// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:vibration/vibration.dart';
import 'home_screen.dart';
import 'settings_screen.dart';
import 'stats_screen.dart';
import 'replay_screen.dart';
import 'replay_detail_screen.dart';
import 'match_detail_screen.dart';
import 'vibration_test_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Ekran yönlendirmesini ayarla
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  
  // Titreşim servisini başlat
  try {
    // Cihazın titreşim özelliğini kontrol et
    bool? hasVibrator = await Vibration.hasVibrator();
    bool? hasAmplitudeControl = await Vibration.hasAmplitudeControl();
    
    print("Cihaz titreşim destekliyor mu: $hasVibrator");
    print("Cihaz titreşim şiddeti kontrolü destekliyor mu: $hasAmplitudeControl");
    
    // Basit bir titreşim testi
    if (hasVibrator == true) {
      Vibration.vibrate(duration: 100);
      print("Titreşim servisi başarıyla başlatıldı");
    }
  } catch (e) {
    print("Titreşim servisi başlatma hatası: $e");
  }
  
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Abluka Oyunu',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.pink,
        fontFamily: 'Roboto',
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const HomeScreen(),
      routes: {
        '/settings': (context) => const SettingsScreen(),
        '/stats': (context) => const StatsScreen(),
        '/replay': (context) => const ReplayScreen(),
        '/replayDetail': (context) => const ReplayDetailScreen(),
        '/matchDetail': (context) => const MatchDetailScreen(),
        '/vibrationTest': (context) => const VibrationTestScreen(),
      },
    );
  }
}
