// ignore_for_file: prefer_const_constructors, prefer_const_declarations

import 'dart:isolate';
import 'dart:convert';
import '../models/board_position.dart';
import '../models/game_board.dart';
import 'abluka_ai.dart';

/// İnsan oyuncuya en iyi hamle önerisi sunan sınıf
class HumanMoveAdvisor {
  /// İnsan oyuncu için en iyi hamleyi hesaplar
  static Future<Map<String, dynamic>> getBestMoveForHuman(
      GameBoard gameBoard, String humanPlayer, String aiPlayer, int depth) async {
    // Isolate iletişimi için port oluştur
    final receivePort = ReceivePort();
    
    // Isolate'e gönderilecek veri
    final Map<String, dynamic> isolateData = {
      'sendPort': receivePort.sendPort,
      'gameBoard': jsonEncode(gameBoard.toJson()),
      'humanPlayer': humanPlayer,
      'aiPlayer': aiPlayer,
      'depth': depth,
    };
    
    // Isolate başlat
    final isolate = await Isolate.spawn(_isolateEntryPoint, isolateData);
    
    // Isolate'den cevap bekle
    final response = await receivePort.first as Map<String, dynamic>;
    
    // Isolate'i kapat
    isolate.kill(priority: Isolate.immediate);
    
    return response;
  }
  
  // Isolate'in çalıştıracağı fonksiyon
  static void _isolateEntryPoint(Map<String, dynamic> data) {
    final SendPort sendPort = data['sendPort'];
    final String gameBoardJson = data['gameBoard'];
    final String humanPlayer = data['humanPlayer'];
    final String aiPlayer = data['aiPlayer'];
    final int depth = data['depth'];
    
    try {
      // GameBoard nesnesini JSON'dan oluştur
      final gameBoard = GameBoard.fromJson(jsonDecode(gameBoardJson));
      
      // İnsan oyuncunun mevcut taş pozisyonu
      final currentPos = gameBoard.pieces[humanPlayer]!.first;
      
      // Geçerli hamleleri kontrol et
      final availableMoves = gameBoard.getAvailableMoves(currentPos);
      
      if (availableMoves.isEmpty) {
        sendPort.send({
          'error': 'Geçerli hamle bulunamadı',
          'success': false,
        });
        return;
      }
      
      // AI'ı insan oyuncu perspektifinden çalıştır
      final ai = AblukaAI(humanPlayer, aiPlayer);
      
      // Tüm olası hamleleri değerlendir ve en iyisini seç
      BoardPosition bestMove = availableMoves.first;
      BoardPosition bestBlock = BoardPosition(0, 0);
      int bestScore = -999999;
      
      for (var move in availableMoves) {
        // Tahtanın geçici bir kopyasını oluştur
        final tempBoard = gameBoard.clone();
        
        // Geçici tahtada hamleyi uygula
        tempBoard.movePiece(humanPlayer, currentPos, move);
        
        // Bu hamle sonrası en iyi engel yerleştirmeyi bul
        final result = ai.getBestActionWithSeparateAnalysis(tempBoard, depth: depth - 1);
        final moveScore = result['bestMoveAnalysis'] is num ? result['bestMoveAnalysis'] as num : 0;
        
        // Eğer bu hamle daha iyiyse, en iyi hamle olarak kaydet
        if (moveScore > bestScore) {
          bestScore = moveScore.toInt();
          bestMove = move;
          bestBlock = result['bestBlock'] as BoardPosition;
        }
        
        // Eğer çok iyi bir hamle bulduysa, daha fazla arama yapma
        if (bestScore > 5000) break;
      }
      
      // Eğer hala (0,0) gibi anlamsız bir konum öneriliyorsa ve oyuncu uzaktaysa düzelt
      if ((bestMove.x == 0 && bestMove.y == 0) && 
          (currentPos.x > 3 || currentPos.y > 3)) {
        // Daha mantıklı bir hamle seç - mevcut konuma yakın olan
        for (var move in availableMoves) {
          // Tahtanın merkezine doğru hareket etmeyi tercih et
          if (move.x > 0 && move.y > 0) {
            bestMove = move;
            
            // Tahtanın geçici bir kopyasını oluştur
            final tempBoard = gameBoard.clone();
            
            // Geçici tahtada hamleyi uygula
            tempBoard.movePiece(humanPlayer, currentPos, move);
            
            // Bu hamle sonrası en iyi engel yerleştirmeyi bul
            final result = ai.getBestActionWithSeparateAnalysis(tempBoard, depth: depth - 1);
            bestBlock = result['bestBlock'] as BoardPosition;
            break;
          }
        }
      }
      
      // Engel yerleştirme için stratejik kontrol
      // Eğer engel rakibin taşına çok uzaksa, daha yakın bir yer seç
      final aiPos = gameBoard.pieces[aiPlayer]!.first;
      final blockDistance = (bestBlock.x - aiPos.x).abs() + (bestBlock.y - aiPos.y).abs();
      
      if (blockDistance > 4) {
        // Rakibe daha yakın bir engel pozisyonu bul
        final tempBoard = gameBoard.clone();
        tempBoard.movePiece(humanPlayer, currentPos, bestMove);
        
        // Boş hücreleri kontrol et
        // Tahta boyutunu 7 olarak varsayalım (standart Abluka tahtası)
        final boardSize = 7;
        for (int x = 0; x < boardSize; x++) {
          for (int y = 0; y < boardSize; y++) {
            if (tempBoard.isEmpty(x, y)) {
              // Rakibe yakın mı kontrol et
              final distance = (x - aiPos.x).abs() + (y - aiPos.y).abs();
              if (distance < blockDistance && distance > 0) {
                bestBlock = BoardPosition(x, y);
              }
            }
          }
        }
      }
      
      // Değerlendirme puanını pozitif bir değere dönüştür
      var moveAnalysis = bestScore;
      if (moveAnalysis < 0) {
        moveAnalysis = moveAnalysis.abs();
      }
      
      // Sonucu ana thread'e gönder
      sendPort.send({
        'bestMove': bestMove.toJson(),
        'bestMoveAnalysis': moveAnalysis,
        'bestBlock': bestBlock.toJson(),
        'bestBlockAnalysis': 'Stratejik engel',
        'success': true,
      });
    } catch (e) {
      // Hata durumunda bildir
      sendPort.send({
        'error': e.toString(),
        'success': false,
      });
    }
  }
}
