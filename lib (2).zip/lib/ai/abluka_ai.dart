import 'dart:math';
import '../models/board_position.dart';
import '../models/game_board.dart';

class AIMove {
  final BoardPosition pieceMove;
  final BoardPosition obstaclePlace;

  AIMove(this.pieceMove, this.obstaclePlace);

  @override
  String toString() =>
      'Move piece to $pieceMove, place obstacle at $obstaclePlace';
}

class AblukaAI {
  final String aiPlayer;
  final String opponentPlayer;
  final Random _random = Random();
  final int _defaultSearchDepth = 4;
  final Map<String, int> _transpositionTable = {};

  AblukaAI(this.aiPlayer, this.opponentPlayer);

  // Oyun durumunu benzersiz bir hash ile tanımlar
  String _hashBoard(GameBoard board) {
    final pieces = board.pieces.entries
        .map((e) => '${e.key}:${e.value.first.x},${e.value.first.y}')
        .join('|');
    final blocks = [
      for (int x = 0; x < 7; x++)
        for (int y = 0; y < 7; y++)
          if (!board.isEmpty(x, y) && !_isPieceAt(board, x, y)) '$x,$y'
    ].join(',');
    return '$pieces|$blocks';
  }
  int _evaluateBoard(GameBoard board) {
    final aiPos = board.pieces[aiPlayer]?.first;
    final opponentPos = board.pieces[opponentPlayer]?.first;
    if (aiPos == null) return -100000;
    if (opponentPos == null) return 100000;

    final aiMoves = board.getAvailableMoves(aiPos).length;
    final opponentMoves = board.getAvailableMoves(opponentPos).length;
    if (aiMoves == 0) return -100000;
    if (opponentMoves == 0) return 100000;

    int mobilityScore = aiMoves * 2 - opponentMoves * 3;
    if (opponentMoves == 1) mobilityScore += 500;
    else if (opponentMoves == 2) mobilityScore += 300;
    else if (opponentMoves <= 3) mobilityScore += 150;

    const centerX = 3, centerY = 3;
    final aiDist = (aiPos.x - centerX).abs() + (aiPos.y - centerY).abs();
    final oppDist = (opponentPos.x - centerX).abs() + (opponentPos.y - centerY).abs();
    final centralityScore = (oppDist - aiDist) * 5;

    int edgePenalty = 0;
    if ([0, 6].contains(aiPos.x) || [0, 6].contains(aiPos.y)) edgePenalty -= 40;
    else if ([1, 5].contains(aiPos.x) || [1, 5].contains(aiPos.y)) edgePenalty -= 20;

    int cornerPenalty = 0;
    if ((aiPos.x <= 1 && aiPos.y <= 1) ||
        (aiPos.x <= 1 && aiPos.y >= 5) ||
        (aiPos.x >= 5 && aiPos.y <= 1) ||
        (aiPos.x >= 5 && aiPos.y >= 5)) {
      cornerPenalty -= 60;
    }

    final distance = (aiPos.x - opponentPos.x).abs() + (aiPos.y - opponentPos.y).abs();
    final proximityScore = distance <= 3 ? (4 - distance) * 15 : 0;

    int cornerTrapScore = 0;
    if ((opponentPos.x <= 1 && opponentPos.y <= 1) ||
        (opponentPos.x <= 1 && opponentPos.y >= 5) ||
        (opponentPos.x >= 5 && opponentPos.y <= 1) ||
        (opponentPos.x >= 5 && opponentPos.y >= 5)) {
      cornerTrapScore = distance <= 3 ? 70 : 40;
    }

    final openSpaceScore = _evaluateOpenSpace(board, aiPos);
    final obstacleScore = _evaluateObstacleControl(board, aiPos, opponentPos);
    final escapeFunnelScore = _evaluateEscapeFunnel(board, opponentPos);

    return mobilityScore * 15 + centralityScore + proximityScore +
           cornerTrapScore + obstacleScore + openSpaceScore +
           escapeFunnelScore + edgePenalty + cornerPenalty;
  }

  int _evaluateEscapeFunnel(GameBoard board, BoardPosition opponentPos) {
    final escapes = board.getAvailableMoves(opponentPos);
    if (escapes.length > 3) return 0;

    int score = 0;
    for (final move in escapes) {
      int surr = _countSurroundingBlocks(board, move);
      if (surr >= 5) score += 60;
      else if (surr >= 3) score += 30;
    }
    return score;
  }

  int _countSurroundingBlocks(GameBoard board, BoardPosition pos) {
    int count = 0;
    for (int dx = -1; dx <= 1; dx++) {
      for (int dy = -1; dy <= 1; dy++) {
        if (dx == 0 && dy == 0) continue;
        int nx = pos.x + dx, ny = pos.y + dy;
        if (_valid(nx, ny) && !board.isEmpty(nx, ny) && !_isPieceAt(board, nx, ny)) count++;
      }
    }
    return count;
  }

  bool _isPieceAt(GameBoard board, int x, int y) {
    final ai = board.pieces[aiPlayer]?.first;
    final op = board.pieces[opponentPlayer]?.first;
    return (ai?.x == x && ai?.y == y) || (op?.x == x && op?.y == y);
  }

  bool _valid(int x, int y) => x >= 0 && x < 7 && y >= 0 && y < 7;

  int _evaluateObstacleControl(GameBoard board, BoardPosition ai, BoardPosition op) {
    return _countSurroundingBlocks(board, op) * 25 -
           _countSurroundingBlocks(board, ai) * 15;
  }
  int _evaluateOpenSpace(GameBoard board, BoardPosition pos) {
    int score = 0;
    for (int dx = -2; dx <= 2; dx++) {
      for (int dy = -2; dy <= 2; dy++) {
        int nx = pos.x + dx, ny = pos.y + dy;
        if (_valid(nx, ny)) {
          if (board.isEmpty(nx, ny)) {
            int d = dx.abs() + dy.abs();
            score += d == 1 ? 15 : (d == 2 ? 5 : 2);
          } else if (!_isPieceAt(board, nx, ny)) {
            int d = dx.abs() + dy.abs();
            score -= d == 1 ? 10 : (d == 2 ? 5 : 1);
          }
        }
      }
    }
    return score;
  }

  List<BoardPosition> _getValidObstaclePlacements(GameBoard board) => [
    for (int x = 0; x < 7; x++)
      for (int y = 0; y < 7; y++)
        if (board.isEmpty(x, y)) BoardPosition(x, y)
  ];

  List<BoardPosition> _orderObstaclePlacements(List<BoardPosition> placements, GameBoard board) {
    final op = board.pieces[opponentPlayer]?.first;
    if (op == null) return placements;

    final scored = placements.map((pos) {
      int base = 0;
      int dist = (pos.x - op.x).abs() + (pos.y - op.y).abs();
      base += dist <= 1 ? 50 : (dist == 2 ? 25 : 0);
      base += (3 - ((pos.x - 3).abs() + (pos.y - 3).abs())) * 2;

      final tmp = board.clone();
      tmp.placeBlock(pos.x, pos.y);
      int diff = board.getAvailableMoves(op).length - tmp.getAvailableMoves(op).length;
      base += diff * 30;

      final secMoves = tmp.getAvailableMoves(op);
      for (final m in secMoves) {
        int s = _countSurroundingBlocks(tmp, m);
        if (s >= 5) base += 25;
      }
      return MapEntry(pos, base);
    }).toList();

    scored.sort((a, b) => b.value.compareTo(a.value));
    return scored.map((e) => e.key).toList();
  }

  int _minimax(GameBoard board, int depth, bool isMax, int alpha, int beta) {
    final hash = _hashBoard(board);
    if (_transpositionTable.containsKey(hash)) return _transpositionTable[hash]!;

    if (depth == 0) {
      int score = _evaluateBoard(board);
      _transpositionTable[hash] = score;
      return score;
    }

    final current = isMax ? aiPlayer : opponentPlayer;
    final pos = board.pieces[current]?.first;
    if (pos == null || board.getAvailableMoves(pos).isEmpty) {
      return isMax ? -100000 : 100000;
    }

    int best = isMax ? -100001 : 100001;
    for (final move in board.getAvailableMoves(pos)) {
      final after = board.clone();
      after.movePiece(current, pos, move);
      for (final block in _orderObstaclePlacements(_getValidObstaclePlacements(after), after).take(5)) {
        final next = after.clone();
        next.placeBlock(block.x, block.y);
        int score = _minimax(next, depth - 1, !isMax, alpha, beta);
        best = isMax ? max(best, score) : min(best, score);
        if (isMax) alpha = max(alpha, best); else beta = min(beta, best);
        if (beta <= alpha) break;
      }
      if (beta <= alpha) break;
    }

    _transpositionTable[hash] = best;
    return best;
  }

  Map<String, dynamic> getBestActionWithSeparateAnalysis(GameBoard board, {int depth = 3}) {
    depth = depth.clamp(1, 4);
    if (_transpositionTable.length > 1000) _transpositionTable.clear();
    final pos = board.pieces[aiPlayer]?.first;
    if (pos == null) return {};
    final moves = board.getAvailableMoves(pos);
    if (moves.isEmpty) return {};

    BoardPosition? bestMove, bestBlock;
    int bestScore = -100001;

    for (final move in moves) {
      final after = board.clone();
      after.movePiece(aiPlayer, pos, move);
      for (final block in _orderObstaclePlacements(_getValidObstaclePlacements(after), after).take(10)) {
        final next = after.clone();
        next.placeBlock(block.x, block.y);
        int score = _minimax(next, depth - 1, false, -100001, 100001);
        if (score > bestScore) {
          bestScore = score;
          bestMove = move;
          bestBlock = block;
        }
      }
    }

    return (bestMove == null || bestBlock == null)
        ? _getRandomMove(board, pos!, moves)
        : {
            'bestMove': bestMove,
            'bestMoveAnalysis': bestScore,
            'bestBlock': bestBlock,
            'bestBlockAnalysis': bestScore,
          };
  }

  Map<String, dynamic> _getRandomMove(GameBoard board, BoardPosition pos, List<BoardPosition> moves) {
    final move = moves[_random.nextInt(moves.length)];
    final after = board.clone();
    after.movePiece(aiPlayer, pos, move);
    final blocks = _getValidObstaclePlacements(after);
    final block = blocks[_random.nextInt(blocks.length)];
    return {
      'bestMove': move,
      'bestMoveAnalysis': 0,
      'bestBlock': block,
      'bestBlockAnalysis': 0,
    };
  }
}
