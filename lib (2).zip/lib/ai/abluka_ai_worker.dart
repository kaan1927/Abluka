import 'dart:isolate';
import 'dart:convert';
import '../models/board_position.dart';
import '../models/game_board.dart';
import 'abluka_ai.dart';

// AI hesaplamalarını ayrı bir isolate'de yapmak için kullanılan worker sınıfı
class AblukaAIWorker {
  // AI hesaplamasını isolate'de çalıştırır
  static Future<Map<String, dynamic>> computeBestMove(
      GameBoard gameBoard, String aiPlayer, String opponentPlayer, int depth) async {
    // Isolate iletişimi için port oluştur
    final receivePort = ReceivePort();
    
    // Isolate'e gönderilecek veri
    final Map<String, dynamic> isolateData = {
      'sendPort': receivePort.sendPort,
      'gameBoard': jsonEncode(gameBoard.toJson()),
      'aiPlayer': aiPlayer,
      'opponentPlayer': opponentPlayer,
      'depth': depth,
    };
    
    // Isolate başlat
    final isolate = await Isolate.spawn(_isolateEntryPoint, isolateData);
    
    // Isolate'den cevap bekle
    final response = await receivePort.first as Map<String, dynamic>;
    
    // Isolate'i kapat
    isolate.kill(priority: Isolate.immediate);
    
    return response;
  }
  
  // Isolate'in çalıştıracağı fonksiyon
  static void _isolateEntryPoint(Map<String, dynamic> data) {
    final SendPort sendPort = data['sendPort'];
    final String gameBoardJson = data['gameBoard'];
    final String aiPlayer = data['aiPlayer'];
    final String opponentPlayer = data['opponentPlayer'];
    final int depth = data['depth'];
    
    try {
      // GameBoard nesnesini JSON'dan oluştur
      final gameBoard = GameBoard.fromJson(jsonDecode(gameBoardJson));
      
      // AI hesaplamasını yap
      final ai = AblukaAI(aiPlayer, opponentPlayer);
      final result = ai.getBestActionWithSeparateAnalysis(gameBoard, depth: depth);
      
      // AI'ın mevcut pozisyonu
      final currentPos = gameBoard.pieces[aiPlayer]!.first;
      
      // Önerilen hamlenin geçerli olup olmadığını kontrol et
      final bestMove = result['bestMove'] as BoardPosition;
      
      // Eğer önerilen hamle (0,0) gibi anlamsız bir konumsa ve AI uzaktaysa düzelt
      if ((bestMove.x == 0 && bestMove.y == 0) && 
          (currentPos.x > 3 || currentPos.y > 3)) {
        
        // Geçerli hamleleri kontrol et
        final availableMoves = gameBoard.getAvailableMoves(currentPos);
        
        // Daha mantıklı bir hamle seç - mevcut konuma yakın olan
        for (var move in availableMoves) {
          // Tahtanın merkezine doğru hareket etmeyi tercih et
          if (move.x > 0 && move.y > 0) {
            // Tahtanın geçici bir kopyasını oluştur
            final tempBoard = gameBoard.clone();
            
            // Geçici tahtada hamleyi uygula
            tempBoard.movePiece(aiPlayer, currentPos, move);
            
            // Bu hamle sonrası en iyi engel yerleştirmeyi bul
            final newResult = ai.getBestActionWithSeparateAnalysis(tempBoard, depth: depth - 1);
            
            // Sonucu güncelle
            sendPort.send({
              'bestMove': move.toJson(),
              'bestMoveAnalysis': result['bestMoveAnalysis'],
              'bestBlock': newResult['bestBlock']?.toJson(),
              'bestBlockAnalysis': newResult['bestBlockAnalysis'],
            });
            return;
          }
        }
      }
      
      // Sonucu ana thread'e gönder
      sendPort.send({
        'bestMove': result['bestMove']?.toJson(),
        'bestMoveAnalysis': result['bestMoveAnalysis'],
        'bestBlock': result['bestBlock']?.toJson(),
        'bestBlockAnalysis': result['bestBlockAnalysis'],
      });
    } catch (e) {
      // Hata durumunda bildir
      sendPort.send({
        'error': e.toString(),
      });
    }
  }
}
