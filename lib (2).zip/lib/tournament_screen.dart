// lib/tournament_screen.dart
import 'package:flutter/material.dart';

class TournamentScreen extends StatefulWidget {
  const TournamentScreen({super.key});
  
  @override
  State<TournamentScreen> createState() => _TournamentScreenState();
}

class _TournamentScreenState extends State<TournamentScreen> {
  List<String> bracket = ["black", "white", "black", "white"];
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Turnuva Sistemi")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("Turnuva Bracketi", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            ...bracket.map((match) => Padding(
              padding: const EdgeInsets.all(4.0),
              child: Text(match == "black" ? "Siyah" : "Beyaz", style: const TextStyle(fontSize: 20)),
            )),
          ],
        ),
      ),
    );
  }
}
