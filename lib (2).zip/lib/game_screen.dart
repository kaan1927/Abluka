import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models/game_board.dart';
import 'models/game_move.dart';
import 'widgets/game_board_widget.dart';
import 'ai/abluka_ai_worker.dart';
import 'ai/human_move_advisor.dart';
import 'end_screen.dart';
import 'models/board_position.dart';
import 'services/vibration_service.dart';

enum GameMode { vsAI, twoPlayer }

class _GameState {
  final GameBoard board;
  final String currentPlayer;
  final int phase; // 1 = Taş Hareketi, 2 = Blok Koyma

  _GameState({
    required this.board,
    required this.currentPlayer,
    required this.phase,
  });
}

class GameScreen extends StatefulWidget {
  final GameMode gameMode;
  const GameScreen({super.key, required this.gameMode});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with TickerProviderStateMixin {
  late GameBoard _board;
  late String _currentPlayer;
  int _phase = 1; // 1 = Taş Hareketi, 2 = Blok Koyma
  final List<_GameState> _history = [];
  final List<GameMove> _moveHistory = [];
  String _humanMoveAdvice = ""; // İnsan oyuncuya hamle önerisi
  int _aiDepth = 4; // Zorluk: Easy=2, Medium=3, Hard=4
  bool _aiThinking = false; // AI düşünüyor mu?
  bool _calculatingHumanMove = false; // İnsan hamlesi hesaplanıyor mu?
  bool _showHints = true; // Hamle ipuçlarını göster/gizle
  bool _vibrationEnabled = true; // Titreşim açık mı?
  final VibrationService _vibrationService = VibrationService(); // Titreşim servisi
  
  // Hesaplama zaman aşımı için
  Timer? _calculationTimeoutTimer;
  
  // Animasyon kontrolcüleri
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    
    // Animasyon kontrolcülerini başlat
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    
    _pulseAnimation = CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    );
    
    _pulseController.repeat(reverse: true);
    
    _loadSettings().then((_) => _initializeGame());
  }
  
  @override
  void dispose() {
    _pulseController.dispose();
    _vibrationService.cancelVibration(); // Titreşimi iptal et
    _calculationTimeoutTimer?.cancel(); // Zamanlayıcıyı iptal et
    super.dispose();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    String difficulty = prefs.getString('difficulty') ?? "Medium";
    bool showHints = prefs.getBool('showHints') ?? true;
    bool vibrationEnabled = prefs.getBool('vibrationEnabled') ?? true;
    
    setState(() {
      // Zorluk ayarına göre AI derinliği belirleniyor.
      if (difficulty == "Easy") {
        _aiDepth = 1;
      } else if (difficulty == "Hard") {
        _aiDepth = 4;
      } else { // Medium
        _aiDepth = 2;
      }
      
      print("Zorluk seviyesi: $difficulty, AI derinliği: $_aiDepth");
      
      _showHints = showHints;
      _vibrationEnabled = vibrationEnabled;
    });
  }

  // Renk seçimi olmadığından, insan oyuncu her zaman "black" (player1) ve AI "white" (player2) olarak başlatılır.
  void _initializeGame() {
    _board = GameBoard(player1: "black", player2: "white");
    _currentPlayer = _board.player1;
    _phase = 1;
    
    // Oyun başladığında insan oyuncuya ilk hamle önerisi sun (eğer ipuçları açıksa)
    if (widget.gameMode == GameMode.vsAI && _showHints) {
      _calculateBestMoveForHuman();
    }
  }

  _GameState _createGameState() =>
      _GameState(board: _board.clone(), currentPlayer: _currentPlayer, phase: _phase);

  // Oyun sonu kontrolü - bir oyuncu hareket edemiyorsa oyun biter
  bool _isGameOver() {
    if (_phase != 1) return false; // Sadece taş hareketi fazında kontrol et
    
    // Mevcut oyuncunun hareket edebileceği yer yoksa oyun biter
    BoardPosition currentPos = _board.pieces[_currentPlayer]!.first;
    bool gameOver = _board.getAvailableMoves(currentPos).isEmpty;
    
    // Oyun bittiyse titreşim ver
    if (gameOver) {
      _vibrateGameEnd();
    }
    
    return gameOver;
  }

  // Kazananı belirle - hareket edemeyen oyuncu kaybeder
  String _determineWinner() {
    // Mevcut oyuncu hareket edemiyorsa, rakip kazanır
    if (_board.getAvailableMoves(_board.pieces[_currentPlayer]!.first).isEmpty) {
      return _currentPlayer == _board.player1 ? _board.player2 : _board.player1;
    }
    
    // Eğer player1 hareket edemiyorsa, player2 kazanır
    if (_board.getAvailableMoves(_board.pieces[_board.player1]!.first).isEmpty) {
      return _board.player2;
    }
    
    // Eğer player2 hareket edemiyorsa, player1 kazanır
    if (_board.getAvailableMoves(_board.pieces[_board.player2]!.first).isEmpty) {
      return _board.player1;
    }
    
    // Varsayılan olarak son hamleyi yapan oyuncu kazanır
    return _currentPlayer == _board.player1 ? _board.player2 : _board.player1;
  }

  Future<void> _storeMatchHistory() async {
    final prefs = await SharedPreferences.getInstance();
    List<dynamic> matchesList = [];
    String? jsonStr = prefs.getString('matches');
    if (jsonStr != null) matchesList = jsonDecode(jsonStr);
    matchesList.add({
      "matchId": "Match ${matchesList.length + 1}",
      "mode": widget.gameMode == GameMode.vsAI ? "vsAI" : "twoPlayer",
      "moves": _moveHistory.length.toString(),
      "winner": _determineWinner(),
      "moveHistory": _moveHistory.map((m) => m.toJson()).toList(),
      "player1": _board.player1,
      "player2": _board.player2,
    });
    await prefs.setString('matches', jsonEncode(matchesList));
  }

  Future<void> updateStats(String winner) async {
    final prefs = await SharedPreferences.getInstance();
    int total = prefs.getInt('totalGames') ?? 0;
    int p1 = prefs.getInt('player1Wins') ?? 0;
    int p2 = prefs.getInt('player2Wins') ?? 0;
    total++;
    if (winner == _board.player1)
      p1++;
    else
      p2++;
    await prefs.setInt('totalGames', total);
    await prefs.setInt('player1Wins', p1);
    await prefs.setInt('player2Wins', p2);
  }

  // İnsan oyuncu için en iyi hamleyi hesapla
  Future<void> _calculateBestMoveForHuman() async {
    // İpuçları kapalıysa veya AI modu değilse hesaplama yapma
    if (!_showHints || _currentPlayer != _board.player1 || widget.gameMode != GameMode.vsAI) return;
    
    setState(() {
      _calculatingHumanMove = true;
      _humanMoveAdvice = "🔍 En iyi hamle hesaplanıyor...";
    });
    
    // Zaman aşımı için timer ayarla - 8 saniye
    _calculationTimeoutTimer?.cancel();
    _calculationTimeoutTimer = Timer(const Duration(seconds: 8), () {
      if (_calculatingHumanMove) {
        setState(() {
          _calculatingHumanMove = false;
          _humanMoveAdvice = "⚠️ Hesaplama zaman aşımına uğradı. Basit bir öneri sunuluyor...";
        });
        
        // Basit bir öneri sun
        _provideFallbackSuggestion();
      }
    });
    
    try {
      // İnsan oyuncu için en iyi hamleyi hesapla
      final result = await HumanMoveAdvisor.getBestMoveForHuman(
        _board,
        _board.player1, // İnsan oyuncu
        _board.player2, // AI
        _aiDepth > 3 ? 3 : _aiDepth // Derinliği sınırla
      );
      
      // Timer'ı iptal et
      _calculationTimeoutTimer?.cancel();
      
      if (result['success'] == true) {
        // JSON'dan BoardPosition nesnelerini oluştur
        final bestMove = BoardPosition.fromJson(result['bestMove']);
        final bestBlock = BoardPosition.fromJson(result['bestBlock']);
        
        // Değerlendirme puanını daha anlaşılır bir şekilde göster
        var moveAnalysis = result['bestMoveAnalysis'];
        String evaluationText;
        
        if (moveAnalysis is num) {
          // Sayısal değeri kalite seviyesine dönüştür
          double score = moveAnalysis.toDouble();
          if (score >= 10000) {
            evaluationText = "Kazandıran hamle! 🏆";
          } else if (score > 1000) {
            evaluationText = "Çok güçlü hamle! 💪";
          } else if (score > 500) {
            evaluationText = "Güçlü hamle 💯";
          } else if (score > 300) {
            evaluationText = "İyi hamle 👍";
          } else if (score > 100) {
            evaluationText = "Makul hamle ✓";
          } else {
            evaluationText = "Kabul edilebilir hamle";
          }
        } else {
          evaluationText = "Önerilen hamle";
        }
        
        setState(() {
          _calculatingHumanMove = false;
          _humanMoveAdvice = 
              "💡 Öneri:\n"
              "🎯 Taşınızı (${bestMove.x},${bestMove.y}) konumuna hareket ettirin\n"
              "🧱 Engeli (${bestBlock.x},${bestBlock.y}) konumuna yerleştirin\n"
              "💯 Değerlendirme: $evaluationText";
        });
      } else {
        setState(() {
          _calculatingHumanMove = false;
          _humanMoveAdvice = "❓ Öneri hesaplanamadı";
        });
        
        // Basit bir öneri sun
        _provideFallbackSuggestion();
      }
    } catch (e) {
      print("Hamle önerisi hatası: $e");
      
      // Timer'ı iptal et
      _calculationTimeoutTimer?.cancel();
      
      setState(() {
        _calculatingHumanMove = false;
        _humanMoveAdvice = "❓ Öneri hesaplanamadı";
      });
      
      // Basit bir öneri sun
      _provideFallbackSuggestion();
    }
  }
  
  // Hesaplama başarısız olduğunda basit bir öneri sun
  void _provideFallbackSuggestion() {
    try {
      final currentPos = _board.pieces[_board.player1]!.first;
      final availableMoves = _board.getAvailableMoves(currentPos);
      
      if (availableMoves.isNotEmpty) {
        // Mevcut konuma en yakın hamleyi seç
        BoardPosition bestMove = availableMoves.first;
        int minDistance = 999;
        
        for (var move in availableMoves) {
          // Merkeze olan uzaklığı hesapla (3,3 merkez kabul edilirse)
          int distance = (move.x - 3).abs() + (move.y - 3).abs();
          if (distance < minDistance) {
            minDistance = distance;
            bestMove = move;
          }
        }
        
        // Boş bir hücre bul (engel için)
        BoardPosition bestBlock = BoardPosition(0, 0);
        final tempBoard = _board.clone();
        tempBoard.movePiece(_board.player1, currentPos, bestMove);
        
        // Rakibin pozisyonu
        final aiPos = _board.pieces[_board.player2]!.first;
        
        // Rakibe yakın bir engel pozisyonu bul
        int bestBlockDistance = 999;
        for (int x = 0; x < 7; x++) {
          for (int y = 0; y < 7; y++) {
            if (tempBoard.isEmpty(x, y)) {
              int distance = (x - aiPos.x).abs() + (y - aiPos.y).abs();
              if (distance < bestBlockDistance && distance > 0) {
                bestBlockDistance = distance;
                bestBlock = BoardPosition(x, y);
              }
            }
          }
        }
        
        setState(() {
          _humanMoveAdvice = 
              "💡 Basit Öneri:\n"
              "🎯 Taşınızı (${bestMove.x},${bestMove.y}) konumuna hareket ettirin\n"
              "🧱 Engeli (${bestBlock.x},${bestBlock.y}) konumuna yerleştirin\n"
              "💯 Değerlendirme: Makul hamle ✓";
        });
      }
    } catch (e) {
      print("Basit öneri hatası: $e");
    }
  }

  Widget _buildTurnIndicator() {
    String playerText = _currentPlayer == _board.player1 ? '⚫ Siyah' : '⚪ Beyaz';
    String phaseText = _phase == 1 ? '🚀 Taş Hareketi' : '🧱 Blok Koyma';
    
    // AI düşünüyorsa özel bir gösterge göster
    if (widget.gameMode == GameMode.vsAI && 
        _currentPlayer == _board.player2 && 
        _aiThinking) {
      return Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF00B4DB), Color(0xFF0083B0)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(
                strokeWidth: 3,
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
              ),
            ),
            const SizedBox(width: 16),
            const Text(
              '🤖 AI düşünüyor...',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      );
    }
    
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFFF416C), Color(0xFFFF4B2B)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFF416C).withOpacity(0.4),
                blurRadius: 12 + (_pulseAnimation.value * 5),
                spreadRadius: 2 + (_pulseAnimation.value * 2),
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.sports_esports,
                color: Colors.white,
                size: 24 + (_pulseAnimation.value * 2),
              ),
              const SizedBox(width: 12),
              Flexible(
                child: Text(
                  'Sıra: $playerText - $phaseText',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 0.2,
                    shadows: [
                      Shadow(
                        color: Colors.black26,
                        blurRadius: 2,
                        offset: Offset(1, 1),
                      ),
                    ],
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // Kullanıcı dokunuşları için; AI turu hariç.
  void _handleTap(int x, int y) {
    if (widget.gameMode == GameMode.vsAI && _currentPlayer == _board.player2) return;
    
    // Oyun bitmiş mi kontrol et
    if (_isGameOver()) return;
    
    setState(() {
      if (_phase == 1) {
        // Taş hareketi fazı
        BoardPosition currentPos = _board.pieces[_currentPlayer]!.first;
        
        if (_board.isEmpty(x, y)) {
          int dx = (x - currentPos.x).abs(), dy = (y - currentPos.y).abs();
          
          // Geçerli hamle kontrolü: Yatay, dikey veya çapraz olarak bir birim hareket
          if (dx <= 1 && dy <= 1 && !(dx == 0 && dy == 0)) {
            _history.add(_createGameState());
            _board.movePiece(_currentPlayer, currentPos, BoardPosition(x, y));
            _moveHistory.add(GameMove(from: currentPos, to: BoardPosition(x, y), block: BoardPosition(-1, -1)));
            _phase = 2; // Engel yerleştirme fazına geç
            
            // Taş hareketi için titreşim
            _vibrateMove();
          }
        }
      } else if (_phase == 2) {
        // Engel yerleştirme fazı
        if (_board.isEmpty(x, y)) {
          _history.add(_createGameState());
          _board.placeBlock(x, y);
          
          // Engel sayısını güncelle (eğer sınırlı engel varsa)
          if (_board.blocksLeft.containsKey(_currentPlayer) && 
              _board.blocksLeft[_currentPlayer]! > 0) {
            _board.blocksLeft[_currentPlayer] = _board.blocksLeft[_currentPlayer]! - 1;
          }
          
          // Hareket geçmişini güncelle
          GameMove last = _moveHistory.last;
          _moveHistory[_moveHistory.length - 1] =
              GameMove(from: last.from, to: last.to, block: BoardPosition(x, y));
          
          _phase = 1; // Taş hareketi fazına geri dön
          _switchTurn(); // Sırayı diğer oyuncuya geçir
          
          // Oyun sonu kontrolü
          if (_isGameOver()) {
            String winner = _determineWinner();
            updateStats(winner);
            _storeMatchHistory();
            Future.delayed(const Duration(seconds: 2), () {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (_) => EndScreen(winner: winner, gameMode: widget.gameMode)));
            });
          }
        }
      }
    });
  }

  void _switchTurn() {
    _currentPlayer = (_currentPlayer == _board.player1) ? _board.player2 : _board.player1;
    
    // AI'ın sırası geldiyse, AI turunu başlat
    if (widget.gameMode == GameMode.vsAI && _currentPlayer == _board.player2) {
      Future.delayed(const Duration(milliseconds: 600), _aiTurn);
    } 
    // İnsan oyuncunun sırası geldiyse ve AI modundaysak ve ipuçları açıksa, hamle önerisi hesapla
    else if (widget.gameMode == GameMode.vsAI && _currentPlayer == _board.player1 && _showHints) {
      Future.delayed(const Duration(milliseconds: 600), _calculateBestMoveForHuman);
    }
  }

  // AI turunda, AI'nın en iyi hamle–blok kombinasyonunu hesaplayıp uyguluyoruz.
  void _aiTurn() async {
    // Oyun bitmiş mi kontrol et
    if (_isGameOver()) {
      String winner = _determineWinner();
      updateStats(winner);
      _storeMatchHistory();
      Future.delayed(const Duration(seconds: 2), () {
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (_) => EndScreen(winner: winner, gameMode: widget.gameMode)));
      });
      return;
    }
    
    // AI düşünmeye başladığını göster
    setState(() {
      _aiThinking = true;
    });
    
    // Zaman aşımı için timer ayarla - 8 saniye
    Timer? aiTimeoutTimer;
    aiTimeoutTimer = Timer(const Duration(seconds: 8), () {
      if (_aiThinking) {
        // Basit bir hamle yap
        _makeSimpleAIMove();
      }
    });
    
    try {
      // Hard modda ise, düşünme animasyonunun görünmesi için kısa bir gecikme ekle
      if (_aiDepth >= 4) {
        await Future.delayed(const Duration(milliseconds: 500));
      }
      
      // AI hesaplamasını ayrı bir isolate'de yap
      // Burada _aiDepth değerini doğrudan geçiriyoruz
      print("AI derinliği: $_aiDepth"); // Derinliği loglayalım
      final action = await AblukaAIWorker.computeBestMove(
        _board, 
        _board.player2, 
        _board.player1, 
        _aiDepth > 3 ? 3 : _aiDepth // Derinliği sınırla
      );
      
      // Timer'ı iptal et
      aiTimeoutTimer.cancel();
      
      // AI'ın geçerli bir hamle döndürdüğünden emin ol
      if (action.isEmpty || action['bestMove'] == null || action['bestBlock'] == null) {
        throw Exception("AI geçerli bir hamle bulamadı");
      }
      
      // JSON'dan BoardPosition nesnelerini oluştur
      final bestMove = BoardPosition.fromJson(action['bestMove']);
      final bestBlock = BoardPosition.fromJson(action['bestBlock']);
      
      final from = _board.pieces[_board.player2]!.first;
      final move = GameMove(from: from, to: bestMove, block: bestBlock);
      
      setState(() {
        _aiThinking = false; // AI düşünmeyi bitirdi
        _history.add(_createGameState());
        
        // Taş hareketini uygula
        _board.movePiece(_board.player2, move.from, move.to);
        
        // Taş hareketi için titreşim
        _vibrateMove();
        
        // Engel yerleştirmeyi uygula
        _board.placeBlock(move.block.x, move.block.y);
        
        // Engel sayısını güncelle (eğer sınırlı engel varsa)
        if (_board.blocksLeft.containsKey(_board.player2) && 
            _board.blocksLeft[_board.player2]! > 0) {
          _board.blocksLeft[_board.player2] = _board.blocksLeft[_board.player2]! - 1;
        }
        
        // Hareket geçmişini güncelle
        _moveHistory.add(move);
        
        // Sırayı insan oyuncuya geçir
        _currentPlayer = _board.player1;
      });
      
      // Oyun sonu kontrolü
      if (_isGameOver()) {
        String winner = _determineWinner();
        updateStats(winner);
        _storeMatchHistory();
        Future.delayed(const Duration(seconds: 2), () {
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (_) => EndScreen(winner: winner, gameMode: widget.gameMode)));
        });
      } else {
        // İnsan oyuncunun sırası geldiyse ve ipuçları açıksa, hamle önerisi hesapla
        if (_showHints) {
          _calculateBestMoveForHuman();
        }
      }
    } catch (e) {
      print("AI hatası: $e");
      
      // Timer'ı iptal et
      aiTimeoutTimer.cancel();
      
      // Basit bir hamle yap
      _makeSimpleAIMove();
    }
  }
  
  // AI için basit bir hamle yap (hesaplama başarısız olduğunda)
  void _makeSimpleAIMove() {
    try {
      final currentPos = _board.pieces[_board.player2]!.first;
      final availableMoves = _board.getAvailableMoves(currentPos);
      
      if (availableMoves.isNotEmpty) {
        // Mevcut konuma en yakın hamleyi seç
        BoardPosition bestMove = availableMoves.first;
        int minDistance = 999;
        
        for (var move in availableMoves) {
          // Merkeze olan uzaklığı hesapla (3,3 merkez kabul edilirse)
          int distance = (move.x - 3).abs() + (move.y - 3).abs();
          if (distance < minDistance) {
            minDistance = distance;
            bestMove = move;
          }
        }
        
        // Tahtanın geçici bir kopyasını oluştur
        final tempBoard = _board.clone();
        
        // Geçici tahtada hamleyi uygula
        tempBoard.movePiece(_board.player2, currentPos, bestMove);
        
        // Boş bir hücre bul (engel için)
        BoardPosition bestBlock = BoardPosition(0, 0);
        
        // İnsan oyuncunun pozisyonu
        final humanPos = _board.pieces[_board.player1]!.first;
        
        // İnsan oyuncuya yakın bir engel pozisyonu bul
        int bestBlockDistance = 999;
        for (int x = 0; x < 7; x++) {
          for (int y = 0; y < 7; y++) {
            if (tempBoard.isEmpty(x, y)) {
              int distance = (x - humanPos.x).abs() + (y - humanPos.y).abs();
              if (distance < bestBlockDistance && distance > 0) {
                bestBlockDistance = distance;
                bestBlock = BoardPosition(x, y);
              }
            }
          }
        }
        
        setState(() {
          _aiThinking = false; // AI düşünmeyi bitirdi
          _history.add(_createGameState());
          
          // Taş hareketini uygula
          _board.movePiece(_board.player2, currentPos, bestMove);
          
          // Taş hareketi için titreşim
          _vibrateMove();
          
          // Engel yerleştirmeyi uygula
          _board.placeBlock(bestBlock.x, bestBlock.y);
          
          // Engel sayısını güncelle (eğer sınırlı engel varsa)
          if (_board.blocksLeft.containsKey(_board.player2) && 
              _board.blocksLeft[_board.player2]! > 0) {
            _board.blocksLeft[_board.player2] = _board.blocksLeft[_board.player2]! - 1;
          }
          
          // Hareket geçmişini güncelle
          _moveHistory.add(GameMove(from: currentPos, to: bestMove, block: bestBlock));
          
          // Sırayı insan oyuncuya geçir
          _currentPlayer = _board.player1;
        });
        
        // Oyun sonu kontrolü
        if (_isGameOver()) {
          String winner = _determineWinner();
          updateStats(winner);
          _storeMatchHistory();
          Future.delayed(const Duration(seconds: 2), () {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (_) => EndScreen(winner: winner, gameMode: widget.gameMode)));
          });
        } else {
          // İnsan oyuncunun sırası geldiyse ve ipuçları açıksa, hamle önerisi hesapla
          if (_showHints) {
            _calculateBestMoveForHuman();
          }
        }
      } else {
        // Eğer geçerli hamle yoksa, AI kaybetti
        setState(() {
          _aiThinking = false;
        });
        
        String winner = _board.player1; // İnsan oyuncu kazandı
        updateStats(winner);
        _storeMatchHistory();
        Future.delayed(const Duration(seconds: 2), () {
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (_) => EndScreen(winner: winner, gameMode: widget.gameMode)));
        });
      }
    } catch (e) {
      print("Basit AI hamle hatası: $e");
      
      // AI düşünmeyi bitirdi (hata ile)
      setState(() {
        _aiThinking = false;
      });
      
      // AI hata verirse, insan oyuncuyu kazanan olarak belirle
      Future.delayed(const Duration(seconds: 2), () {
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (_) => EndScreen(winner: _board.player1, gameMode: widget.gameMode)));
      });
    }
  }

  // Taş hareketi için titreşim
  Future<void> _vibrateMove() async {
    if (_vibrationEnabled) {
      await _vibrationService.vibrateOnMove();
    }
  }

  // Oyun sonu için titreşim
  Future<void> _vibrateGameEnd() async {
    if (_vibrationEnabled) {
      await _vibrationService.vibrateOnGameEnd();
    }
  }

  void _undoMove() {
    if (_history.isNotEmpty) {
      setState(() {
        final prev = _history.removeLast();
        _board = prev.board;
        _currentPlayer = prev.currentPlayer;
        _phase = prev.phase;
        
        // Eğer hareket geçmişi varsa ve geri alınan hamle son hamle ise, onu da kaldır
        if (_moveHistory.isNotEmpty && _phase == 1) {
          _moveHistory.removeLast();
        }
        
        // İnsan oyuncunun sırası ise ve AI modundaysak ve ipuçları açıksa, hamle önerisi hesapla
        if (widget.gameMode == GameMode.vsAI && _currentPlayer == _board.player1 && _showHints) {
          Future.delayed(const Duration(milliseconds: 600), _calculateBestMoveForHuman);
        }
      });
    }
  }

  void _resetGame() {
    setState(() {
      _initializeGame();
      _history.clear();
      _moveHistory.clear();
      _humanMoveAdvice = "";
      _aiThinking = false;
      _calculatingHumanMove = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(
          'ABLUKA',
          style: TextStyle(
            fontFamily: 'Arial',
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Colors.white,
            letterSpacing: 2.0,
            shadows: [
              Shadow(
                color: Colors.black38,
                offset: Offset(0, 2),
                blurRadius: 4,
              ),
            ],
          ),
        ),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
              ),
              child: Center(
                child: AblukaBoardButton(
                  icon: Icons.refresh, 
                  onPressed: _resetGame,
                ),
              ),
            ),
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF6A3093), // Mor
              Color(0xFFA044FF), // Mor-Pembe
              Color(0xFFE73C7E), // Pembe
              Color(0xFFEE7752), // Turuncu
              Color(0xFFFDB731), // Sarı-Turuncu
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildTurnIndicator(),
              Expanded(
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20.0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(24),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.25),
                            spreadRadius: 2,
                            blurRadius: 15,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      padding: const EdgeInsets.all(12),
                      child: GameBoardWidget(
                        board: _board,
                        onCellTapped: _handleTap,
                      ),
                    ),
                  ),
                ),
              ),
              // Öneri paneli - sadece ipuçları açıksa ve AI modundaysa göster
              if (_showHints && widget.gameMode == GameMode.vsAI)
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  height: 120, // Sabit yükseklik
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  margin: const EdgeInsets.only(bottom: 20, top: 10),
                  child: _currentPlayer == _board.player1
                    ? Container(
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF11998E), Color(0xFF38EF7D)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.25),
                              blurRadius: 10,
                              spreadRadius: 1,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: _calculatingHumanMove
                              ? Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      width: 24,
                                      height: 24,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2.5,
                                        valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
                                      ),
                                    ),
                                    const SizedBox(width: 16),
                                    const Text(
                                      "En iyi hamle hesaplanıyor...",
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                )
                              : SingleChildScrollView(
                                  child: Text(
                                    _humanMoveAdvice.isNotEmpty 
                                        ? _humanMoveAdvice 
                                        : "Hamle önerisi bekleniyor...",
                                    style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.white,
                                      height: 1.4,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                        ),
                      )
                    : const SizedBox.shrink(), // AI sırasında öneri gösterme
                ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: Padding(
        padding: EdgeInsets.only(
          // Öneri paneli açıksa daha yukarıda, kapalıysa daha aşağıda konumlandır
          bottom: (_showHints && widget.gameMode == GameMode.vsAI) ? 150.0 : 20.0,
        ),
        child: Align(
          alignment: Alignment.bottomCenter,
          child: AblukaBoardButton(
            icon: Icons.undo, 
            onPressed: _undoMove,
            size: 32,
          ),
        ),
      ),
    );
  }
}

/// Abluka oyunu için özel tasarlanmış buton.
class AblukaBoardButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onPressed;
  final double size;

  const AblukaBoardButton({
    super.key,
    required this.icon,
    required this.onPressed,
    this.size = 28,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFFDB731), Color(0xFFFF9800)],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            spreadRadius: 1,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          customBorder: const CircleBorder(),
          splashColor: Colors.white.withOpacity(0.3),
          highlightColor: Colors.white.withOpacity(0.1),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Icon(
              icon,
              size: size,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}
